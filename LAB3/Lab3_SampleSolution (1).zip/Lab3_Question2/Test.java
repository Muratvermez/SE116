package Lab3_Question2;

import java.util.Scanner;
public class Test {
    public static void main(String[] args){
        Patient[] patientList=new Patient[5];
        int choice;

        Scanner scan1=new Scanner(System.in);

        while(true) {
            displayMenu();
            choice = scan1.nextInt();

            switch (choice) {
                case 1:
                    storePatient(patientList); // method storePatient is called here. The array reference is passed to the method.
                    break; // switch-case is broken here

                case 2:
                    for (Patient aPatient : patientList) {  /* foreach element in array */
                        if(aPatient!=null) {
                            aPatient.printInfo();
                            System.out.println();
                        }
                    }
                    /*
                    OR:
                    for(int i=0;i<patientList.length;i++){
                        if(patientList[i]!=null){
                            patientList[i].printInfo();
                            System.out.println();
                        }
                    }
                    */
                    /*
                    OR:
                    int i=0;
                    while (i<patientList.length) {
                        if(patientList[i]!=null){
                            patientList[i].printInfo();
                            System.out.println();
                        }
                        i++;
                    }
                    */
                    break; // switch-case is broken here

                case 3:
                    System.out.println("Terminating the program...");
                    System.exit(0); // the method exit directly quits the program

                default:
                    System.out.println("Wrong choice! Please enter a choice between 1 and 3");
            }
        }
    } // end of main

    public static void displayMenu(){ // The method displayMenu is static, because of that the static method main will call it
        System.out.println("A sample hospital information system is running now...");
        System.out.println("MENU OPTIONS [1 through 3]:");
        System.out.println("*** Press 1 to store information     ***");
        System.out.println("*** Press 2 to print information     ***");
        System.out.println("*** Press 3 to terminate the program ***");
        System.out.println("Your choice? :");
    } // end of the method displayMenu

    public static void storePatient(Patient[] patients) {
        int tempId, tempAge;
        String tempName, tempDiagnosis;
        Scanner scan2=new Scanner(System.in);

        // Let's check whether the array is full or not
        boolean isArrayFull = true; // let's suppose that the array is full and then check whether the case is true or not
        for (int i = 0; i < patients.length; i++) {
            if (patients[i] == null) { // no Patient object is referred by the location i of the array
                isArrayFull = false; // if any location is null, then the array is not full, there is one empty location at least.
                break;
            }
        }
        if (isArrayFull) { // OR: if(isArrayFull==true){
            System.out.println("Array is full!!!!!");
            return;   // If the array is full, no new patient will be added
        }

        // We know here that the array is not full, so let's add the reference of a new Patient into the first suitable location of the array
        for (int i = 0; i < patients.length; i++) {
            if (patients[i] == null) { // let's find the first suitable location
                Patient pat = new Patient(); // let's create a new Patient
                System.out.println("Please enter Patient's information...");

                System.out.print("ID: ");
                tempId = scan2.nextInt();
                scan2.nextLine();  // to fix the problem that there waits a '\n' (newLine character) in Scanner object
                pat.setPatientID(tempId); // let's set the corresponding data of the object

                System.out.print("Name: ");
                tempName = scan2.nextLine();
                pat.setFullName(tempName);

                System.out.print("Age: ");
                tempAge = Integer.parseInt(scan2.nextLine()); // to fix the '\n' character problem, the value is read as a String and then is converted to int
                /*
                tempAge=scan2.nextInt();
                scan2.nextLine();
                */
                pat.setAge(tempAge);

                System.out.print("Diagnosis: ");
                tempDiagnosis = scan2.nextLine();
                pat.setDiagnosis(tempDiagnosis);

                patients[i] = pat; // let's make the location i of the array refer to the corresponding Patient object

                break;  // Here, the loop is broken. So, only one new patient will be added into array
            }
        }
    } // end of the method storePatient
} // end of class Test
