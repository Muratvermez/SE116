package Lab3_Question2;

public class Patient {
    private int patientID;   // using the access modifier private, data members are encapsulated (accessible in class scope only)
    private String fullName;
    private int age;
    private String diagnosis;

    public int getPatientID() { // methods are public (accessible everywhere)
        return patientID;
    }

    public void setPatientID(int pID) { // set methods modify the data
        patientID = pID;
    }

    public String getFullName() { // get methods return the data
        return fullName;
    }

    public void setFullName(String fName) {
        fullName = fName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int pAge) {
        age = pAge;
    }

    public String getDiagnosis() {
        return diagnosis;
    }

    public void setDiagnosis(String diag) {
        diagnosis = diag;
    }

    public void printInfo(){
        System.out.println("PATIENT INFO");
        System.out.println("-------");
        System.out.println("ID        : "+patientID); // OR: System.out.println("ID        : " + getPatientID() );
        System.out.println("NAME      : "+fullName);
        System.out.println("AGE       : "+age);
        System.out.println("DIAGNOSIS : "+diagnosis);
    }
} // end of class Patient