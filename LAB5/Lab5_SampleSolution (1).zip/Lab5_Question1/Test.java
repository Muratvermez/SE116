import java.util.Scanner;

public class Test {
    public static void main (String[] args){
        Scanner scan = new Scanner (System.in);
        Car cars[] = new Car [5]; // array object is defined here
        String tempModel;
        int tempMY;
        double tempPriceTS;

        //Filling the array with Car instances.
        for(int i=0; i<cars.length; i++)
            cars[i]=new Car();  // a new Car instance is ready to use here

        //Calling printInfo for each car.
        for(int i=0; i<cars.length; i++)
            cars[i].printInfo();

        // OR:
        /*
        //Calling printInfo for each car.
        for(Car tempCar : cars)
            tempCar.printInfo();
        */

        //Obtaining the information of cars from the user
        for(int i=0;i<cars.length;i++){
            System.out.println("Please enter the model of your car: ");
            tempModel=scan.nextLine();
            cars[i].setModel(tempModel);
            //cars[i].setModel(scan.nextLine()); // Same task stated in a different way

            System.out.println("Please enter the model year of your car: ");
            tempMY=scan.nextInt();
            cars[i].setModelYear(tempMY);
            //cars[i].setModelYear(scan.nextInt());

            System.out.println("Please enter the maximum speed you can achieve: ");
            tempPriceTS=scan.nextDouble();
            cars[i].setTopSpeed(tempPriceTS);

            System.out.println("Please enter the price of your car: ");
            tempPriceTS=scan.nextDouble();
            cars[i].setPrice(tempPriceTS);
            scan.nextLine(); // // to resolve the following issue: After reading a double using nextDouble(), there is still a '\n' (newLine character) in Scanner object to be read
            System.out.println();
        }

        System.out.println();

        //Calling printInfo for each car again.
        for(int i=0;i<cars.length;i++)
            cars[i].printInfo();

    }
}