public class Car {
    private int modelYear;
    private String model;
    private double topSpeed;
    private double price;

    public Car() {  // non-parameterized constructor (default constructor)
        this.modelYear = 0;
        this.model = "Unknown";
        this.topSpeed = 0.0;
        this.price = 0.0;
    }
    public int getModelYear() {
        return this.modelYear;
    }
    public void setModelYear(int modelYear) {
        this.modelYear = modelYear;
    }
    public String getModel() {
        return this.model;
    }
    public void setModel(String model) {
        this.model = model;
    }
    public double getTopSpeed() {
        return this.topSpeed;
    }
    public void setTopSpeed(double topSpeed) {
        this.topSpeed = topSpeed;
    }
    public double getPrice() {
        return this.price;
    }
    public void setPrice(double parameterPrice) {
        if(parameterPrice<0.0)  // input validation
            parameterPrice = 0.0;
        this.price = parameterPrice;
    }
    public void printInfo(){
        System.out.println("CAR INFO");
        System.out.println("--------");
        System.out.println("MODEL     : " + this.model);
        System.out.println("YEAR      : " + modelYear);
        System.out.println("TOP-SPEED : " + getTopSpeed());
        System.out.println("PRICE     : " + this.getPrice());
        System.out.println();
    }
}