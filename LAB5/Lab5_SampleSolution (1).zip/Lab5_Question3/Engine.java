public class Engine {
    private double volume;
    private int numberOfCylinders;

    public double getVolume() {
        return this.volume;
    }
    public void setVolume(double volume) {
        this.volume = volume;
    }
    public int getNumberOfCylinders() {
        return this.numberOfCylinders;
    }
    public void setNumberOfCylinders(int numberOfCylinders) {
        this.numberOfCylinders = numberOfCylinders;
    }

    // constructor method may not have any return type, not even void
    public Engine() { // non-parameterized constructor
        this.volume = 0.0;
        this.numberOfCylinders = 0;
        // to return the name of the class the following statement can be used:   getClass().getName();
        System.out.println("A new "+ this.getClass().getName() +" object is being constructed using non-parameterized constructor.");
    }
    // constructor method can be overloaded
    public Engine(double volumeParameter, int numberOfCylindersParameter) { // parameterized constructor
        this.setVolume(volumeParameter);
        this.setNumberOfCylinders(numberOfCylindersParameter);
        System.out.println("A new "+ this.getClass().getName() +" object is being constructed using parameterized constructor.");
    }
}