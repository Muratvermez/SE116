import java.util.Scanner;

public class Test {
    public static void main (String[] args){
        Scanner scan = new Scanner(System.in);

        String tempModel;
        int tempMY, tempNoCy;
        double tempPrice, tempTS;
        double tempVol;
        Engine tempEng = new Engine(); // non-parameterized constructor of class Engine is called

        System.out.println();
        System.out.println("The number of Car objects constructed: " + Car.getCarCounter());
        System.out.println();

        Car firstCarReference = new Car(); // non-parameterized constructor of class Car is called

        System.out.println();
        firstCarReference.printInfo();

        System.out.println("The number of Car objects constructed: " + Car.getCarCounter());
        System.out.println();

        Car secondCarReference=new Car(2011, "Ford", 34.0, 1200, tempEng); // parameterized constructor of class Car is called

        System.out.println();
        secondCarReference.printInfo();

        System.out.println("The number of Car objects constructed: " + Car.getCarCounter());
        System.out.println();

        // User enters data
        System.out.println("Please enter the model of your car: ");
        tempModel=scan.nextLine();

        System.out.println("Please enter the model year of your car: ");
        tempMY=scan.nextInt();

        System.out.println("Please enter the maximum speed you can achieve: ");
        tempTS=scan.nextDouble();

        System.out.println("Please enter the price of your car: ");
        tempPrice=scan.nextDouble();

        System.out.println("Please enter your engine specs: ");
        System.out.print(" --> Volume : ");
        tempVol=scan.nextDouble();
        tempEng.setVolume(tempVol);
        System.out.print(" --> Number of Cylinders : ");
        tempNoCy=scan.nextInt();
        tempEng.setNumberOfCylinders(tempNoCy);

        System.out.println();
        Car thirdCarReference = new Car(tempMY, tempModel, tempTS, tempPrice, tempEng); // parameterized constructor of class Car is called
        System.out.println();
        thirdCarReference.printInfo();

        System.out.println("The number of Car objects constructed: " + Car.getCarCounter());
        System.out.println();

        Engine anotherEng = new Engine(4000.0, 6); // parameterized constructor of class Engine is called

        System.out.println();
        Car fourthCarReference = new Car(1973, "Anadol", 4, 16500.0, anotherEng); // parameterized constructor of class Car is called
        System.out.println();
        fourthCarReference.printInfo();

        System.out.println("The number of Car objects constructed: " + Car.getCarCounter());
        System.out.println();

        Car fifthCarReference = new Car(tempMY, tempModel, 4, 39000.0, new Engine());
        System.out.println();
        fifthCarReference.printInfo();
        System.out.println();

        System.out.println("The number of Car objects constructed: " + Car.getCarCounter());
        System.out.println();

        fifthCarReference.getEng().setVolume(2000.0);
        fifthCarReference.getEng().setNumberOfCylinders(4);
        fifthCarReference.printInfo();

        System.out.println("The number of Car objects constructed: " + Car.getCarCounter());
    }
}