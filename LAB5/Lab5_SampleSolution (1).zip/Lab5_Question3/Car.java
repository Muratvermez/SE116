public class Car {
    private int modelYear;
    private String model;
    private double topSpeed; // a non-static data member is an instance variable and it will be stored in each different instance of the class.
    private double price;
    private Engine eng; // eng is a reference
    private static int carCounter=0; // a static data member is a class variable and it's not to be stored in any instance of the class, it's shared by the class instead.

    public Car() { // non-parameterized constructor
        setModelYear(0);
        setModel("Unknown");
        this.setTopSpeed(0.0);
        this.setPrice(0.0);
        this.eng = new Engine(); // eng refers to the new object defined here
        // Once a Car object is constructed, the value of carCounter will be incremented.
        carCounter++; // let's not use the the reference this to access the static members
        System.out.println("A new "+ this.getClass().getName() +" object is being constructed using non-parameterized constructor.");
    }
    public Car(int modelYear, String model, double topSpeed, double price, Engine eng) { // parameterized constructor
        this.setModelYear(modelYear);
        setModel(model);
        this.topSpeed = topSpeed;
        setPrice(price);
        this.eng = eng;
        carCounter++;
        System.out.println("A new "+ this.getClass().getName() +" object is being constructed using parameterized constructor." );
    }

    // static methods deal with static data members
    public static int getCarCounter() {
        return carCounter; // "this" cannot be referenced from a static context
    }

    public Engine getEng() {
        return this.eng;
    }
    public void setEng(Engine parameterEng) {
        this.eng = parameterEng;
    }
    public int getModelYear() {
        return this.modelYear;
    }
    public void setModelYear(int modelYear) {
        this.modelYear = modelYear;
    }
    public String getModel() {
        return this.model;
    }
    public void setModel(String model) {
        this.model = model;
    }
    public double getTopSpeed() {
        return this.topSpeed;
    }
    public void setTopSpeed(double topSpeed) {
        this.topSpeed = topSpeed;
    }
    public double getPrice() {
        return this.price;
    }
    public void setPrice(double parameterPrice) {
        if(parameterPrice<0.0)  // input validation
            parameterPrice = 0.0;
        this.price = parameterPrice;
    }
    public void printInfo(){
        System.out.println("CAR INFO");
        System.out.println("--------");
        System.out.println("MODEL     : " + model);
        System.out.println("YEAR      : " + modelYear);
        System.out.println("TOP-SPEED : " + topSpeed);
        System.out.println("PRICE     : " + price);
        System.out.println("ENGINE    : ");
        System.out.println("  -->VOLUME         : " + eng.getVolume());
        System.out.println("  --># of CYLINDERS : " + eng.getNumberOfCylinders());
        System.out.println();
    }
}
