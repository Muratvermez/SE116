public class Car {
    private int modelYear;
    private String model;  /* "has-a" relationship: Car "has-a" String */
    private double topSpeed;
    private double price;
    /* "has-a" relationship: Car "has-a" Engine */
	private Engine eng; // eng is a reference

    public Car() { // non-parameterized constructor (default constructor)
        this.modelYear = 0;
        this.model = "Unknown";
        this.topSpeed = 0.0;
        this.price = 0.0;
        this.eng = new Engine(); // eng refers to the new object defined here
    }
    public Engine getEng() {
        return this.eng;
    }
    public void setEng(Engine parameterEng) {
        this.eng = parameterEng;
    }
    public int getModelYear() {
        return this.modelYear;
    }
    public void setModelYear(int modelYear) {
        this.modelYear = modelYear;
    }
    public String getModel() {
        return this.model;
    }
    public void setModel(String model) {
        this.model = model;
    }
    public double getTopSpeed() {
        return this.topSpeed;
    }
    public void setTopSpeed(double topSpeed) {
        this.topSpeed = topSpeed;
    }
    public double getPrice() {
        return this.price;
    }
    public void setPrice(double parameterPrice) {
        if(parameterPrice<0.0)  // input validation
            parameterPrice = 0.0;
        this.price = parameterPrice;
    }
    public void printInfo(){
        System.out.println("CAR INFO");
        System.out.println("--------");
        System.out.println("MODEL     : " + model);
        System.out.println("YEAR      : " + modelYear);
        System.out.println("TOP-SPEED : " + topSpeed);
        System.out.println("PRICE     : " + price);
        System.out.println("ENGINE    : ");
        System.out.println("  -->VOLUME         : " + eng.getVolume());
        System.out.println("  --># of CYLINDERS : " + eng.getNumberOfCylinders());
        System.out.println();
    }
}
