import java.util.Scanner;

public class Test {
    public static void main (String[] args){
        Scanner scan = new Scanner(System.in);
        final int SIZE = 5; // constant variable
        Car cars[] = new Car[SIZE]; // array object with length SIZE

        String tempModel;
        int tempMY, tempNoCy;
        double tempPriceTS;
        double tempVol;

        // Filling the array with Car instances.
        for(int i=0; i<cars.length; i++)
            cars[i]=new Car();  // a new Car instance is ready to use here

        // Calling printInfo for each car.
        for(Car c : cars)
            c.printInfo();

        // OR:
        /*
        //Calling printInfo for each car.
        for(int i=0; i<cars.length; i++)
            cars[i].printInfo();
        */

        // Reading (obtaining) the information of cars from the user
        for(int i=0;i<cars.length;i++){
            System.out.println("Please enter the model of your car: ");
            tempModel=scan.nextLine();
            cars[i].setModel(tempModel);
            //cars[i].setModel(scan.nextLine()); A different way...

            System.out.println("Please enter the model year of your car: ");
            tempMY=scan.nextInt();
            cars[i].setModelYear(tempMY);
            //cars[i].setModelYear(scan.nextInt());

            System.out.println("Please enter the maximum speed you can achieve: ");
            tempPriceTS=scan.nextDouble();
            cars[i].setTopSpeed(tempPriceTS);

            System.out.println("Please enter the price of your car: ");
            tempPriceTS=scan.nextDouble();
            cars[i].setPrice(tempPriceTS);

            System.out.println("Please enter your engine specs: ");
            System.out.print(" --> Volume : ");
            tempVol=scan.nextDouble();
            cars[i].getEng().setVolume(tempVol);
            System.out.print(" --> Number of Cylinders : ");
            tempNoCy=scan.nextInt();
            cars[i].getEng().setNumberOfCylinders(tempNoCy);

            scan.nextLine(); // to resolve the following issue: After reading an integer using nextInt(), there is still a '\n' (newLine character) in Scanner object to be read

            System.out.println();
        }

        System.out.println();

        // Calling printInfo for each car again.
        for(int i=0; i<cars.length; i++)
            cars[i].printInfo();

    }
}