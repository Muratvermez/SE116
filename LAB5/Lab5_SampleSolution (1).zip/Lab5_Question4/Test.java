import java.util.ArrayList;
import java.util.Scanner;

public class Test {
    public static void main (String[] args){
        Scanner scan = new Scanner(System.in);

        String tempModel;
        int tempMY, tempNoCy;
        double tempPrice, tempTS;
        double tempVol;
        String userResponse;

        System.out.println();
        System.out.println("The number of Car objects constructed so far: " + Car.getCarCounter());
        System.out.println();

        ArrayList<Car> myCars= new ArrayList<Car>();

        System.out.println("The number of Car objects constructed so far: " + Car.getCarCounter());
        System.out.println();

        while(true) {
            // User enters new input data
            System.out.print("Please enter the model of the new car: ");
            tempModel = scan.nextLine();

            System.out.print("Please enter the model year of the car: ");
            tempMY = scan.nextInt();

            System.out.print("Please enter the maximum speed of the car: ");
            tempTS = scan.nextDouble();

            System.out.print("Please enter the price of the car: ");
            tempPrice = scan.nextDouble();

            System.out.println("Please enter the engine specs of the car: ");
            System.out.print(" --> Volume: ");
            tempVol = scan.nextDouble();
            System.out.print(" --> Number of Cylinders: ");
            tempNoCy = scan.nextInt();

            scan.nextLine(); // to resolve the issue that there is still a '\n' (newLine character) in Scanner object to be read

            Car aCarReference = new Car(tempMY, tempModel, tempTS, tempPrice, new Engine(tempVol,tempNoCy));
            myCars.add(aCarReference); // the reference of a Car object is added into the ArrayList object

            System.out.println();
            System.out.println("The number of Car objects constructed so far: " + Car.getCarCounter());
            System.out.println();
            System.out.println("DO YOU WISH TO ADD A NEW CAR? " +
                    " (Press 'Q' or Enter \"Quit\" to QUIT the program " +
                    " OR " +
                    " Press/Enter any other key to KEEP ON ADDING A NEW CAR)");

            userResponse=scan.nextLine();
            if( userResponse.equals("Quit")
                    || userResponse.equals("Q")
                    || userResponse.equals("QUIT")
                    || userResponse.equals("q")
                    || userResponse.equals("quit")
                    || userResponse.equals("No")
                    || userResponse.equals("N")
                    || userResponse.equals("NO")
                    || userResponse.equals("n")
                    || userResponse.equals("no") ) {
                break;
            }
        }

        for(int i=0; i<myCars.size(); i++){
            myCars.get(i).printInfo();
        }
    }
}