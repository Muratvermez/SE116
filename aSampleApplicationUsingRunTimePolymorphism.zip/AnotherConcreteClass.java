public class AnotherConcreteClass implements TheSecondInterfaceImplementable {
    @Override
    public String secondAbstractMethod() {
        System.out.println("secondAbstractMethod defined in AnotherConcreteClass runs...");
        return "The CE/SE students should try hands-on programming labs...";
    }
}
