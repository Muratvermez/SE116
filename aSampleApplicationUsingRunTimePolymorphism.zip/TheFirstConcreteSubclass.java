public class TheFirstConcreteSubclass extends TheAbstractClass {
    @Override
    public void thirdAbstractMethod() {
        System.out.println("thirdAbstractMethod defined in TheFirstConcreteSubclass runs...");
    }

}
