public class TheConcreteClass implements TheFirstInterfaceImplementable {
    public int firstAbstractMethod() {
        System.out.println("firstAbstractMethod defined in TheConcreteClass runs...");
        return 1;
    }
}