public interface TheSecondInterfaceImplementable {
    String secondAbstractMethod();
}