public abstract class TheAbstractClass {
    public abstract void thirdAbstractMethod();
}