public class Test {
    public static void main(String[] args) {
        TheAbstractClass[] firstArray = new TheAbstractClass[2];
        firstArray[0] = new TheFirstConcreteSubclass();
        firstArray[1] = new TheSecondConcreteSubclass();

        TheFirstInterfaceImplementable[] secondArray = new TheFirstInterfaceImplementable[3];
        secondArray[0] = new TheConcreteClass();
        secondArray[1] = new TheSecondConcreteSubclass();
        secondArray[2] = new TheThirdConcreteSubclass();

        TheSecondInterfaceImplementable[] thirdArray = new TheSecondInterfaceImplementable[2];
        thirdArray[0] = new AnotherConcreteClass();
        thirdArray[1] = new TheThirdConcreteSubclass();

        // the statements below illustrate the use of run-time polymorphism:
        for(TheAbstractClass guestVariable : firstArray) {
            guestVariable.thirdAbstractMethod(); // run-time polymorphism is used here
        }

        for(TheFirstInterfaceImplementable guestVariable : secondArray) {
            int result = guestVariable.firstAbstractMethod(); // run-time polymorphism is used here
            System.out.println(result);
        }

        for(TheSecondInterfaceImplementable guestVariable : thirdArray) {
            String valueReturned = guestVariable.secondAbstractMethod(); // run-time polymorphism is used here
            System.out.println(valueReturned);
        }

        // the statements below illustrate the use of downcasting:
        for(TheAbstractClass guestVariable : firstArray) {
            if(guestVariable instanceof TheSecondConcreteSubclass) {
                TheSecondConcreteSubclass anotherVariable = (TheSecondConcreteSubclass) guestVariable; // downcasting is used here
                int result = anotherVariable.firstAbstractMethod();
                System.out.println(result);
            }
        }

        for(TheFirstInterfaceImplementable guestVariable : secondArray) {
            if(guestVariable instanceof TheSecondConcreteSubclass) {
                TheSecondConcreteSubclass anotherVariable = (TheSecondConcreteSubclass) guestVariable; // downcasting is used here
                anotherVariable.thirdAbstractMethod();
            }
            if(guestVariable instanceof TheThirdConcreteSubclass) {
                TheThirdConcreteSubclass anotherVariable = (TheThirdConcreteSubclass) guestVariable; // downcasting is used here
                String valueReturned = anotherVariable.secondAbstractMethod();
                System.out.println(valueReturned);
                anotherVariable.thirdAbstractMethod();
            }
        }

        for(TheSecondInterfaceImplementable guestVariable : thirdArray) {
            if(guestVariable instanceof TheThirdConcreteSubclass) {
                TheThirdConcreteSubclass anotherVariable = (TheThirdConcreteSubclass) guestVariable; // downcasting is used here
                int result = anotherVariable.firstAbstractMethod();
                System.out.println(result);
                anotherVariable.thirdAbstractMethod();
            }
        }
    }
}