public interface TheFirstInterfaceImplementable {
    /*public abstract*/ int firstAbstractMethod();
}