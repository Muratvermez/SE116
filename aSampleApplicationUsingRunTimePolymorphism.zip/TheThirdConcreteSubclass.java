public class TheThirdConcreteSubclass extends TheAbstractClass implements TheFirstInterfaceImplementable , TheSecondInterfaceImplementable {
    @Override
    public void thirdAbstractMethod() {
        System.out.println("thirdAbstractMethod defined in TheThirdConcreteSubclass runs...");
    }
    @Override
    public int firstAbstractMethod() {
        System.out.println("firstAbstractMethod defined in TheThirdConcreteSubclass runs...");
        return 3;
    }
    @Override
    public String secondAbstractMethod() {
        System.out.println("secondAbstractMethod defined in TheThirdConcreteSubclass runs...");
        return "Students learned the use of interface and abstract classes...";
    }
}