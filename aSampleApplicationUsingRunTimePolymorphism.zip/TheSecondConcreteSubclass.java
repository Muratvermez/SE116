public class TheSecondConcreteSubclass extends TheAbstractClass implements TheFirstInterfaceImplementable {
    @Override
    public void thirdAbstractMethod() {
        System.out.println("thirdAbstractMethod defined in TheSecondConcreteSubclass runs...");
    }
    @Override
    public int firstAbstractMethod() {
        System.out.println("firstAbstractMethod defined in TheSecondConcreteSubclass runs...");
        return 2;
    }
}