package Lab4_Question2;

import java.util.Scanner;
public class Test {
    public static void main(String[] args){
        Scanner scan=new Scanner(System.in);

        System.out.print("Please enter the number of the workers in the factory: ");
        int numberOfWorkers=scan.nextInt();

        Worker[] workers=new Worker[numberOfWorkers];

        int tempID;
        double tempSal;
        String tempName, tempDescription;
        boolean tempMasterValue;

        for(int i=0;i<workers.length;i++) {
            Worker work = new Worker();
            System.out.println("Please enter Worker's information...");

            System.out.println("ID: ");
            tempID = scan.nextInt();
            scan.nextLine(); // in order to read the waiting character '\n'
            work.setWorkerID(tempID);

            System.out.println("Name: ");
            tempName = scan.nextLine();
            work.setFullName(tempName);

            System.out.println("Monthly Salary: ");
            tempSal = scan.nextDouble();
            scan.nextLine(); // in order to read the waiting character '\n'
            work.setMonthlySalary(tempSal);

            System.out.println("Job Description: ");
            tempDescription = scan.nextLine();
            work.setJobDescription(tempDescription);

            System.out.println("Is this worker master (please enter either true or false): ");
            tempMasterValue = scan.nextBoolean();
            // scan.nextLine(); // in order to read the waiting character '\n'
            work.setWorkerMasterValue(tempMasterValue);

            workers[i]=work;
        }

        System.out.println("Printing information.....");
        displayWorkersArrayInfo(workers);

    } // end of main

    public static void displayWorkersArrayInfo(Worker[] workers){
        for(int i=0;i<workers.length;i++) {
            System.out.println("WORKER INFO");
            System.out.println("-------");
            System.out.println("ID              : " + workers[i].getWorkerID());
            System.out.println("NAME            : " + workers[i].getFullName());
            System.out.printf("ANNUAL SALARY  : %.3f\n" , workers[i].calculateAnnualIncome()); // in order to print in a formatted way using 3 digits in precision
            System.out.println("JOB DESC.       : " + workers[i].getJobDescription());
            System.out.println();
        }
        /*
        OR:
        for(Worker content : workers) {
            System.out.println("WORKER INFO");
            System.out.println("-------");
            System.out.println("ID              : " + content.getWorkerID());
            System.out.println("NAME            : " + content.getFullName());
            System.out.println("ANNUAL SALARY  : " + content.calculateAnnualIncome());
            System.out.println("JOB DESC.       : " + content.getJobDescription());
            System.out.println();
        }
        */
    } // end of displayWorkersArrayInfo
}// end of class Test
