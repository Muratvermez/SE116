package Lab4_Question2;

/*
 * Source code file name: Worker.java
 * The class Worker contains four data members and corresponding methods to set and get their values.
*/

public class Worker {
    /*
    The fields (data members) of a class can be specified as private/public.
    The concept of encapsulation (information hiding): The data members that should be hidden are declared with the keyword private, the methods that should be accessible out of the class are declared with the keyword public.
    The access modifier (access specifier) public allows the corresponding item to be accessible everywhere.
    The access modifier (access specifier) private allows the corresponding item to be accessible in class scope only.
    If there is no modifier used, then the field will be specified as package-private (accessible in package, not accessible outside of the package).
    */

    /* data members */
    private int workerID;  /* The non-static data members are also called as instance variables */
    private String fullName;
    private double monthlySalary;
    private String jobDescription;
    private boolean isMaster;

    /* methods */
    public int getWorkerID() { /* Accessor methods return (retrieve) the values of the data members */
        return workerID;
    }

    public void setWorkerID(int wID) {  /* Mutator methods set (modify) the values of the data members */
        workerID = wID;
        return; // since the method returns no value, it is not necessary to write here "return". In default, every method returns at the end of its body.
    }

    public String getFullName() {
        return fullName; // the value of fullName of the object will be returned to the caller of the method
    }

    public void setFullName(String fName) { // setFullName method sets the fullName of the object
        fullName = fName; // the following is also OK: this.fullName=fName;
    }

    public double getMonthlySalary() {
        return monthlySalary;
    }

    public void setMonthlySalary(double mSalary) { // mSalary parameter is a local variable of the method
        if(mSalary<0.0){ // validation mechanism for the argument value
            mSalary=0.0;
        }

        monthlySalary = mSalary;
    }

    public String getJobDescription() {
        return jobDescription;  // equivalent with the following statement:  return this.jobDescription;
    }

    public void setJobDescription(String jDescription) {
        jobDescription = jDescription;
        /* return; */
    }

    public boolean getIsWorkerMaster() {
        return isMaster;
    }

    public void setWorkerMasterValue(boolean masterValue) {
        isMaster = masterValue;
    }

    public double calculateAnnualIncome(){
        if(isMaster) {
            return ( 12*monthlySalary + (20.0/100.0)*(12*monthlySalary) );
        }
        else {
            return 12*monthlySalary;
        }
    } // end of the method calculateAnnualIncome
} // end of class Worker