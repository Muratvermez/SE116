package Lab4_Question3;

import java.util.Scanner;
public class Test {
    public static void main(String[] args){
        Scanner scan=new Scanner(System.in);

        System.out.print("Please enter the number of the workers in the factory: ");
        int numberOfWorkers=scan.nextInt();

        Worker[] workers=new Worker[numberOfWorkers];

        int tempID;
        double tempSal;
        String tempName, tempDescription;
        boolean tempMasterValue;

        for(int i=0;i<workers.length;i++) {
            Worker work = new Worker();
            System.out.println("Please enter Worker's information...");

            System.out.println("ID: ");
            tempID = scan.nextInt();
            scan.nextLine(); // in order to read the waiting character '\n'
            work.setWorkerID(tempID);

            System.out.println("Name: ");
            tempName = scan.nextLine();
            work.setFullName(tempName);

            System.out.println("Monthly Salary: ");
            tempSal = scan.nextDouble();
            scan.nextLine(); // in order to read the waiting character '\n'
            work.setMonthlySalary(tempSal);

            System.out.println("Job Description: ");
            tempDescription = scan.nextLine();
            work.setJobDescription(tempDescription);

            System.out.println("Is this worker master (please enter either true or false): ");
            tempMasterValue = scan.nextBoolean();
            scan.nextLine(); // in order to read the waiting character '\n'
            work.setWorkerMasterValue(tempMasterValue);

            workers[i]=work;
        }

        System.out.println("Printing information.....");
        displayWorkersArrayInfo(workers);

        maximumAnnualSalariedWorker(workers);
        minimumAnnualSalariedWorker(workers);

        System.out.println("Enter a job description value to be searched: ");
        tempDescription = scan.nextLine();
        searchWorkerByJobDescription(workers, tempDescription);
    } // end of main

    public static void displayWorkersArrayInfo(Worker[] wArray){
        for(int i=0;i<wArray.length;i++) {
            System.out.println("WORKER INFO");
            System.out.println("-------");
            System.out.println("ID              : " + wArray[i].getWorkerID());
            System.out.println("NAME            : " + wArray[i].getFullName());
            System.out.printf("ANNUAL SALARY  : %.3f\n", wArray[i].calculateAnnualIncome()); // in order to print in a formatted way using 3 digits in precision
            System.out.println("JOB DESC.       : " + wArray[i].getJobDescription());
            System.out.println();
        }
        /*
        OR:
        for(Worker content : wArray) {
            System.out.println("WORKER INFO");
            System.out.println("-------");
            System.out.println("ID              : " + content.getWorkerID());
            System.out.println("NAME            : " + content.getFullName());
            System.out.printf("ANNUAL SALARY  : %.3f\n", content.calculateAnnualIncome()); // in order to print in a formatted way using 3 digits in precision
            System.out.println("JOB DESC.       : " + content.getJobDescription());
            System.out.println();
        }
        */
    } // end of displayWorkersArrayInfo

    public static void maximumAnnualSalariedWorker(Worker[] wArray){
        Worker max=wArray[0];  // let's suppose that the first reference in the array refers to the worker with maximum annual salary
        for(int i=1; i<wArray.length; i++){
            if(max.calculateAnnualIncome()<wArray[i].calculateAnnualIncome()) {
                max=wArray[i];
            }
        }
        System.out.println("INFO OF THE WORKER WITH THE HIGHEST ANNUAL SALARY:");
        System.out.println("-----------------");
        System.out.println("ID              : " + max.getWorkerID());
        System.out.println("NAME            : " + max.getFullName());
        System.out.printf("ANNUAL SALARY  : %.3f\n", max.calculateAnnualIncome()); // in order to print in a formatted way using 3 digits in precision
        System.out.println("JOB DESC.       : " + max.getJobDescription());
        System.out.println();
    } // end of the method maximumAnnualSalariedWorker

    public static void minimumAnnualSalariedWorker(Worker[] wArray){
        Worker min=wArray[0];  // let's suppose that the first reference in the array refers to the worker with minimum annual salary
        for(int i=1; i<wArray.length; i++){
            if(min.calculateAnnualIncome()>wArray[i].calculateAnnualIncome()) {
                min=wArray[i];
            }
        }

        System.out.println("INFO OF THE WORKER WITH THE LOWEST ANNUAL SALARY:");
        System.out.println("-----------------");
        System.out.println("ID              : " + min.getWorkerID());
        System.out.println("NAME            : " + min.getFullName());
        System.out.printf("ANNUAL SALARY  : %.3f\n", min.calculateAnnualIncome());
        System.out.println("JOB DESC.       : " + min.getJobDescription());
        System.out.println();
    } // end of the method minimumAnnualSalariedWorker


    public static void searchWorkerByJobDescription(Worker[] wArray, String keyJobDescription){
        boolean isFound=false;
        for(int i=0; i<wArray.length; i++){
            if(wArray[i].getJobDescription().equals(keyJobDescription)) {
                System.out.println("INFO OF THE THE WORKER FOUND:");
                System.out.println("-----------------");
                System.out.println("ID              : " + wArray[i].getWorkerID());
                System.out.println("NAME            : " + wArray[i].getFullName());
                System.out.printf("ANNUAL SALARY  : %.3f\n", wArray[i].calculateAnnualIncome());
                System.out.println("JOB DESC.       : " + wArray[i].getJobDescription());
                System.out.println();
                isFound=true;
            }
        }
        if(!isFound){
            System.out.println("There is no worker with the job description " + keyJobDescription);
        }
    } // end of the method searchWorkerByJobDescription
}// end of class Test