// CommissionEmployee is an Employee

public class CommissionEmployee extends Employee {
    private double grossSales;
    private double commissionRate;

    public void setGrossSales(double ceSales) {
        if(ceSales < 0.0 )
            throw new IllegalArgumentException("Gross sales must be non-negative.");

        this.grossSales = ceSales;
    }

    public double getGrossSales() {
        return this.grossSales;
    }

    public void setCommissionRate(double ceRate) {
        if(ceRate < 0.0 || ceRate > 1.0)
            throw new IllegalArgumentException("Commission rate must fall in the range [0.0, 1.0].");

        this.commissionRate = ceRate;
    }

    public double getCommissionRate() {
        return this.commissionRate;
    }

    public CommissionEmployee() { // non-parameterized constructor
        super();
        this.setGrossSales(0.0);
        this.setCommissionRate(0.0);
    }

    public CommissionEmployee(String eName, int eID, double ceSales, double ceRate) { // parameterized constructor
        super(eName, eID);
        this.setGrossSales(ceSales);
        this.setCommissionRate(ceRate);
    }

    public CommissionEmployee(CommissionEmployee ceReference) { // copy constructor
        super(ceReference);
        this.setGrossSales(ceReference.getGrossSales());
        this.setCommissionRate(ceReference.getCommissionRate());
    }

    @Override
    public void display() {
        super.display();
        System.out.println("Earnings: " + this.getGrossSales()*this.getCommissionRate());
    }
} // end of class CommissionEmployee
