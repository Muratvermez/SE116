// sample inheritance application: an Employee hierarchy

public class Employee  /* extends Object */ {
    private final String name; // constant data member
    private final int ID;
    private static int numberOfEmployees = 0; // static data member

    public String getName() {
        return this.name;
    }

    public int getID() {
        return this.ID;
    }

    public static int getNumberOfEmployees() { // static method
        return numberOfEmployees;
    }

    public Employee() { // non-parameterized constructor
        this.name = "NoName";
        this.ID = 0;
        numberOfEmployees++;
    }

    public Employee(String eName, int eID) { // parameterized constructor
        this.name = eName;
        this.ID = eID;
        numberOfEmployees++;
    }

    public Employee(Employee empReference) { // copy constructor
        this.name = empReference.getName();
        this.ID = empReference.getID();
        numberOfEmployees++;
    }

    public void display() {
        System.out.println("Name    : " + this.getName());
        System.out.println("ID      : " + this.getID());
    }

} // end of class Employee