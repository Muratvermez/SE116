// SalariedEmployee is an Employee

public class SalariedEmployee extends Employee {
    private double salary; // instance variable (non-static data member)

    public void setSalary(double seSalary) {
        if(seSalary < 0.0 ) // input validation
            throw new IllegalArgumentException("Salary must be non-negative."); // throw exception

        this.salary = seSalary;
    }

    public double getSalary() {
        return this.salary;
    }

    public SalariedEmployee() { // non-parameterized constructor
        super();
        this.setSalary(0.0);
    }

    public SalariedEmployee(String eName, int eID, double seSalary) { // parameterized constructor
        super(eName, eID);
        this.setSalary(seSalary);
    }

    public SalariedEmployee(SalariedEmployee seReference) { // copy constructor
        super(seReference);
        this.setSalary(seReference.getSalary());
    }

    @Override
    public void display() {
        super.display();
        System.out.println("Earnings: " + this.getSalary());
    }
} // end of class SalariedEmployee
