// HourlyEmployee is an Employee

public class HourlyEmployee extends Employee {
    private double wagePerHour;
    private double totalHoursWorked;

    public void setWagePerHour(double heWage) {
        if(heWage < 0.0 )
            throw new IllegalArgumentException("Wage must be non-negative.");

        this.wagePerHour = heWage;
    }

    public double getWagePerHour() {
        return this.wagePerHour;
    }

    public void setTotoalHoursWorked(double heHours) {
        if(heHours < 0.0 )
            throw new IllegalArgumentException("Total hours worked must be non-negative.");

        this.totalHoursWorked = heHours;
    }

    public double getTotalHoursWorked() {
        return this.totalHoursWorked;
    }

    public HourlyEmployee() { // non-parameterized constructor
        super();
        this.setWagePerHour(0.0);
        this.setTotoalHoursWorked(0.0);
    }

    public HourlyEmployee(String eName, int eID, double heWage, double heHours) { // parameterized constructor
        super(eName, eID);
        this.setWagePerHour(heWage);
        this.setTotoalHoursWorked(heHours);
    }

    public HourlyEmployee(HourlyEmployee heReference) { // copy constructor
        super(heReference);
        this.setWagePerHour(heReference.getWagePerHour());
        this.setTotoalHoursWorked(heReference.getTotalHoursWorked());
    }

    @Override
    public void display() {
        super.display();
        System.out.println("Earnings: " + this.getWagePerHour()*this.getTotalHoursWorked());
    }
} // end of class HourlyEmployee