public class Test {
    public static void main(String[] args) {
        System.out.println("number of employees: " + Employee.getNumberOfEmployees()); // public static methods can be called using the class name
        System.out.println();

        Employee eRef1 = new Employee();
        eRef1.display();

        System.out.println("number of employees: " + SalariedEmployee.getNumberOfEmployees()); // public static methods can be called using the class name
        System.out.println();

        Employee eRef2 = new Employee("İlker", 111);
        eRef2.display();

        System.out.println("number of employees: " + eRef2.getNumberOfEmployees());
        System.out.println();

        SalariedEmployee sRef1 = new SalariedEmployee("Kaya", 112, 1000.0);
        sRef1.display();

        System.out.println("number of employees: " + Employee.getNumberOfEmployees());
        System.out.println();

        SalariedEmployee sRef2 = new SalariedEmployee(sRef1);
        sRef2.display();

        System.out.println("number of employees: " + HourlyEmployee.getNumberOfEmployees());
        System.out.println();

        HourlyEmployee hRef1 = new HourlyEmployee("Erdem", 114, 20.0, 35.5);
        hRef1.display();

        System.out.println("number of employees: " + Employee.getNumberOfEmployees());
        System.out.println();

        CommissionEmployee cRef1 = new CommissionEmployee("Deniz", 115, 9200.0, 0.15);
        cRef1.display();

        System.out.println("number of employees: " + CommissionEmployee.getNumberOfEmployees());
        System.out.println();

        Employee eRef3 = new SalariedEmployee("Nehir", 116, 1500.0);
        eRef3.display();

        System.out.println("number of employees: " + cRef1.getNumberOfEmployees());
        System.out.println();

        try {
            HourlyEmployee hRef2 = new HourlyEmployee("Derya", 117, -15.0, 20);
            System.out.println("If an exeption is occured in the above statment, the rest of the block \"try\" can not execute...");
            hRef2.display();
        }
        catch (IllegalArgumentException e){
            System.out.println("An exception is caught here. The message is: \n" + e.getMessage());
        }
        finally {
            System.out.println("The block \"finally\" always executes...");
        }

        System.out.println();

        System.out.println("number of employees: " + Employee.getNumberOfEmployees());
        System.out.println();

        Employee eRef4 = cRef1;
        eRef4.display();

        System.out.println("number of employees: " + Employee.getNumberOfEmployees());
        System.out.println();
    } // end of main
} // end of class Test