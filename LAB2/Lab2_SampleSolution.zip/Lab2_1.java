/**
 *  A sample solution for Lab#2_1 of SE 116
 *  created by Ilker Korkmaz
**/

import java.util.Scanner;

public class Lab2_1 {
    public static void main(String[] args) {
        Scanner inputData = new Scanner(System.in);

        System.out.println("A sample scientific calculator is running now ...");

        boolean willRepeatAgain = true;
        while(willRepeatAgain) {
            System.out.println("Here are the menu options for your choice [1 through 5] :");
            System.out.println("*** Press 1 to calculate POWER       ***");
            System.out.println("*** Press 2 to calculate SQUARE ROOT ***");
            System.out.println("*** Press 3 to calculate MAXIMUM     ***");
            System.out.println("*** Press 4 to calculate LOGARITHM   ***");
            System.out.println("*** Press 5 to TERMINATE the program ***");
            System.out.print("Your choice? : ");

            int choice = inputData.nextInt();

            double firstInput, secondInput, result;

            switch (choice){
                case 1:
                    System.out.println("The power operation takes 2 real values as input parameters: base and exponent.");
                    System.out.print("Enter the base value: ");
                    firstInput = inputData.nextDouble();  // the method nextDouble() will read a real value
                    System.out.print("Enter the exponent value: ");
                    secondInput = inputData.nextDouble();
                    result = Math.pow(firstInput,secondInput);
                    System.out.println("The result is " + result);
                    break;
                case 2:
                    System.out.println("The square root operation takes a real input parameter.");
                    System.out.print("Enter the input: ");
                    firstInput = inputData.nextDouble();
                    result = Math.sqrt(firstInput);
                    System.out.println("The result is " + result);
                    break;
                case 3:
                    System.out.println("The maximum operation takes 2 real values as input parameters.");
                    System.out.print("Enter the first value: ");
                    firstInput = inputData.nextDouble();
                    System.out.print("Enter the second value: ");
                    secondInput = inputData.nextDouble();
                    result = Math.max(firstInput,secondInput);
                    System.out.println("The result is " + result);
                    break;
                case 4:
                    System.out.println("The logarithm operation (in base e) takes a real input parameter.");
                    System.out.print("Enter the input: ");
                    firstInput = inputData.nextDouble();
                    result = Math.log(firstInput);
                    System.out.println("The result is " + result);
                    break;
                case 5:
                    System.out.println("Program quits ...");
                    willRepeatAgain = false;
                    /*
                    System.exit(0); // the method exit() makes the program immediately quit
                    */
                    break;
                default:
                    System.out.println("Wrong choice???");
                    break;
            }
        }
    }
}