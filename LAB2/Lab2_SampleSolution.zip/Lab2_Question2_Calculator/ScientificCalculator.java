/**
 *  A sample solution for Lab#2_2 of SE 116
 *  The solution package, Lab2_Question2_Calculator, includes the following two classes: class ScientificCalculator and class Driver
 *  This source file implements the class ScientificCalculator
 *  created by Ilker Korkmaz
**/

package Lab2_Question2_Calculator;

public class ScientificCalculator {
    public static void displayMenu() {
        System.out.println("Here are the menu options for your choice [1 through 6] :");
        System.out.println("*** Press 1 to calculate POWER       ***");
        System.out.println("*** Press 2 to calculate SQUARE ROOT ***");
        System.out.println("*** Press 3 to calculate MAXIMUM     ***");
        System.out.println("*** Press 4 to calculate LOGARITHM   ***");
        System.out.println("*** Press 5 to calculate FACTORIAL   ***");
        System.out.println("*** Press 6 to TERMINATE the program ***");
        System.out.print("Your choice? : ");
    }

    public static double calculatePower(double base, int exp) {
        // let's implement an iterative algorithm:
        double powerResult = 1.0;
        for (int i = 1; i <= exp; i++) {  // assumption: exp is a nonnegative integer
            powerResult *= base;
        }
        return powerResult;

        /*
        // or a recursive algorithm:  power(b,e)= b*power(b,e-1)
        if(exp==0){
            return 1;
        }
        else{  // assumption: exp is a nonnegative integer
            return (base*calculatePower(base,exp-1));
        }
        */

        /*
        //  alternatively, we can call the related static method provided by class Math
        return Math.pow(base,exp);
        */
    }

    public static double calculateSquareRoot(double input) {
        double sqrtResult;
        sqrtResult = Math.sqrt(input);
        return sqrtResult;
    }

    public static double calculateMaximum(double first, double second) {
        if (first > second) {
            return first;
        }
        else {
            return second;
        }
    }

    public static double calculateLogarithm(double input) {
        return Math.log(input);
    }

    public static int calculateFactorial(int n) {  // assumption: n is nonnegative (n>=0)
        // recursive algorithm:
        if(n==0) {  // base condition
            return 1;
        }
        else {      // recursive condition
            return (n*calculateFactorial(n-1));
        }

        /*
        // iterative algorithm:
        int factorialValue = 1;
        for (int i = 1; i <= n; i++) {
            factorialValue *= i;
        }
        return factorialValue;
        */
    }
}