/**
 *  A sample solution for Lab#2_2 of SE 116
 *  The solution package, Lab2_Question2_Calculator, includes the following two classes: class ScientificCalculator and class Driver
 *  This source file implements the class Driver
 *  created by Ilker Korkmaz
**/

package Lab2_Question2_Calculator;

import java.util.Scanner;

public class Driver {
    public static void main(String[] args) {
        Scanner inputData = new Scanner(System.in);

        System.out.println("A sample scientific calculator is running now ...");

        boolean willRepeatAgain = true;
        while (willRepeatAgain) {
            ScientificCalculator.displayMenu();
            int choice = inputData.nextInt();
            double firstInput, secondInput, result;
            int factorialInput;
            switch (choice) {
                case 1:
                    System.out.println("The power operation takes a real (double) base and an integer exponent as input parameters.");
                    System.out.print("Enter the base value: ");
                    firstInput = inputData.nextDouble();
                    System.out.print("Enter the exponent value: ");
                    secondInput = inputData.nextInt();
                    result = ScientificCalculator.calculatePower(firstInput, (int)secondInput);  // casting from double to int
                    System.out.println("The result is " + result);
                    break;
                case 2:
                    System.out.println("The square root operation takes a real input parameter.");
                    System.out.print("Enter the input: ");
                    firstInput = inputData.nextDouble();
                    result = ScientificCalculator.calculateSquareRoot(firstInput);
                    System.out.println("The result is " + result);
                    break;
                case 3:
                    System.out.println("The maximum operation takes 2 real values as input parameters.");
                    System.out.print("Enter the first value: ");
                    firstInput = inputData.nextDouble();
                    System.out.print("Enter the second value: ");
                    secondInput = inputData.nextDouble();
                    result = ScientificCalculator.calculateMaximum(firstInput, secondInput);
                    System.out.println("The result is " + result);
                    break;
                case 4:
                    System.out.println("The logarithm operation (in base e) takes a real input parameter.");
                    System.out.print("Enter the input: ");
                    firstInput = inputData.nextDouble();
                    result = ScientificCalculator.calculateLogarithm(firstInput);
                    System.out.println("The result is " + result);
                    break;
                case 5:
                    System.out.println("The factorial operation takes a non-negative decimal value.");
                    System.out.print("Enter the input: ");
                    factorialInput = inputData.nextInt();
                    result = ScientificCalculator.calculateFactorial(factorialInput);
                    System.out.println("The result is " + result);
                    break;
                case 6:
                    System.out.println("Program quits ...");
                    willRepeatAgain = false;
                    /*
                    System.exit(0); // exit method makes the program immediately quit
                     */
                    break;
                default:
                    System.out.println("Wrong choice???");
                    break;
            }
        }
    }
}