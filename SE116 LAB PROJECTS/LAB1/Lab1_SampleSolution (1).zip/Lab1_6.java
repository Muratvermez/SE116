/**
 *  A sample solution for Lab#1_6 of SE 116
 *  created by Ilker Korkmaz
**/

public class Lab1_6 {
    public static void main(String[] args){
        int result=1;
        int base=5, exp=3;

        for(int i=1; i<=exp; i++){
            result = result * base;
        }

        System.out.println(base + " to the power of " + exp + " is equal to " + result);

        // an alternative :
        double result2;
        result2 = Math.pow(5.0,3.0);
        System.out.println(base + " to the power of " + exp + " is equal to " + result2);
    }
}