/**
 *  A sample solution for Lab#1_7 of SE 116
 *  created by Ilker Korkmaz
**/

import java.util.Scanner;
public class Lab1_7 {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        System.out.println("Enter a base and an exponent to compute the value of base to the power of exponent:");
        int base=input.nextInt();
        int exp=input.nextInt();

        int result=1;
        for(int i=1; i<=exp; i++){
            result = result * base;
        }

        System.out.println(base + " to the power of " + exp + " is equal to " + result);
    }
}