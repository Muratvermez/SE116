/**
 *  A sample solution for Lab#1_8 of SE 116
 *  created by Ilker Korkmaz
**/

import java.util.Scanner;
public class Lab1_8 {
    public static void main(String[] args) {
        final int SIZE = 8; // as a style, constants are identified in UPPERCASE LETTERS
        int key, minimum;
        int[] numbersArray; // declaration of an array
        numbersArray= new int[SIZE]; // creation of the array object

        Scanner input = new Scanner(System.in);

        System.out.println("Please enter " + SIZE +" integer values.");
        // fill the array using the values to be entered by the user
        for(int i=0; i<numbersArray.length; i++) {  // numbersArray.length is equal to SIZE
            System.out.print("Enter " + (i+1) + ". number: ");
            numbersArray[i] = input.nextInt();
        }

        System.out.println();

        //print out the contents of the array
        System.out.println("Array contains the following values:");
        for(int i=0; i<numbersArray.length; i++) {
            System.out.print(numbersArray[i]+" ");
        }

        System.out.println();

        //print out the contents of the array using the enhanced for statement
        //enhanced for statement can be used only to obtain array elements; it cannot be used to modify the elements.
        System.out.println("Array contains the following values:");
        for(int content : numbersArray) { // enhanced for statement
            System.out.print(content+" ");
        }

        System.out.println();

        System.out.print("Please enter a key value to be searched in array: ");
        key = input.nextInt();

        // search a key value in the array
        boolean flag= false;
        for(int i=0; i<SIZE; i++) { // the following is also OK:  for(int i=0; i<numbersArray.length; i++)
            if(numbersArray[i] == key) { // compare the values
                flag = true;
                break;
            }
        }

        if(flag) {
            System.out.println("Found");
        }
        else {
            System.out.println("Not found");
        }

        System.out.println();

        // find the minimum value in the array
        minimum = numbersArray[0]; // let minimum value be the first element in the array
        for(int i=1; i<numbersArray.length; i++) {
            if(numbersArray[i]<minimum) { // compare
                minimum = numbersArray[i]; // update the minimum value
            }
        }
        System.out.println("Minimum value is "+minimum);
    }
}
