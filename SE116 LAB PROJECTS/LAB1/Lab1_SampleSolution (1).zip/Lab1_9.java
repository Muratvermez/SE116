/**
 *  A sample solution for Lab#1_9 of SE 116
 *  created by Ilker Korkmaz
**/

public class Lab1_9 {
    public static void main(String[] args){
        System.out.println("5! = " + iterativeFactorial(5));
        System.out.println("5! = " + recursiveFactorial(5));
    }

    public static int iterativeFactorial(int n){ // assumption n>=0
        int result = 1;
        for(int i=1; i<=n; i++){
            result = result * i;
        }
        return result;
    }

    public static int recursiveFactorial(int n){ // assumption n>=0
        if(n == 0){  // base condition
            return 1;
        }
        else{        // recursive condition
            return n*recursiveFactorial(n-1);
        }
    }
}
