/**
 *  A sample solution for Lab#1_5 of SE 116
 *  created by Ilker Korkmaz
**/

import java.util.Scanner;
public class Lab1_5 {
    public static void main(String[] args){
        final int SIZE=30; // constant
        int[] array = new int[SIZE];  // an array object is instantiated in memory

        Scanner input = new Scanner(System.in);
        System.out.println("Enter " + SIZE + " integer temperature values:");
        for(int i=0; i<array.length; i++){
            array[i] = input.nextInt();
        }

        int highestTemp = array[0];
        int hotDays = 0;
        for(int value : array){ // enhanced for loop
            if(value > 33){
                hotDays++;
            }
            if(value > highestTemp){
                highestTemp = value;
            }
        }

        System.out.println("The total number of hot days: " + hotDays);
        System.out.println("The highest temperature value: " + highestTemp);
    }
}