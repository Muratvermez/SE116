/**
 *  A sample solution for Lab#1_2 of SE 116
 *  created by Ilker Korkmaz
**/

import java.util.Scanner;
public class LAB6_2 {
    public static void main(String[] args) {
        int temp;
        int hottestDay;
        int coldestDay;
        int sum=0;
        double avg=0.0;
        int hdays=0;
        int pldays=0;
        int cdays=0;

        Scanner scanner=new Scanner(System.in);

        System.out.println("Please enter degree values in Celsius " +
                "(enter -1000 to quit):");
        temp=scanner.nextInt();
        hottestDay = temp; // Suppose that the first entered value is the highest one
        coldestDay = temp; // Suppose that the first entered value is the lowest one

        while(temp != -1000) {
            if(temp>=30) {
                System.out.println(temp + " is a hot day");
                hdays++;
                sum=sum+temp;
            }
            else if(temp>=17 && temp<30 ) {
                System.out.println(temp + " is a pleasant day");
                pldays++;
                sum=sum+temp;
            }
            else {
                System.out.println(temp + " is a cold day");
                cdays++;
                sum=sum+temp;
            }

            if (temp > hottestDay) {
                hottestDay=temp;
            }

            if (temp < coldestDay) {
                coldestDay=temp;
            }

            // System.out.println("Please enter a new value:");
            temp=scanner.nextInt();
        }

        if(coldestDay!=-1000) { // false refers that no degree value has entered
            System.out.print("\n");
            System.out.println("Number of cold days: " + cdays);
            System.out.println("Number of pleasant days: " + pldays);
            System.out.println("Number of hot days: " + hdays);
            System.out.print("\n");
            System.out.println("The lowest temperature is " + coldestDay + " degrees Celsius.");
            System.out.println("The highest temperature is " + hottestDay + " degrees Celsius.");

            avg = (double)sum / (cdays + hdays + pldays);  // cast from int to double
            System.out.println("Average temperature is " + avg + " degrees Celsius.");
        }
        else {
            System.out.println("No value entered... No need to compute anything...");
        }
    }
}