/**
 *  A sample solution for Lab#1_1 of SE 116
 *  created by Ilker Korkmaz
**/

import java.util.Scanner;  // class Scanner should be imported for reading data from the user

public class Lab1_1 {
    public static void main (String[] args) {
        int temp;
        System.out.print("Please enter a degree value (in Celsius): ");

        Scanner scanner = new Scanner (System.in);  // an object of class Scanner will be used to read data from the user
        temp=scanner.nextInt();  // the method nextInt() of class Scanner will read an integer data

        if(temp>=30) {
            System.out.println(temp +" is a hot day.");
        }
        else if(temp<30 && temp>=17) {
            System.out.println(temp +" is a pleasant day.");
        }
        else {
            System.out.println(temp +" is a cold day.");
        }
    }
}