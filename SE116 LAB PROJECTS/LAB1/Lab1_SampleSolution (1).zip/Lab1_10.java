/**
 *  A sample solution for Lab#1_10 of SE 116
 *  created by Ilker Korkmaz
**/

import java.util.Scanner;
public class Lab1_10 {
    public static void main(String [] args) {
        int row = 3, column=2, maximum;

        int[][] matrix1 = new int[row][column];  // two-dimensional array definition
        int[][] matrix2 = new int[row][column];
        int[][] result = new int[row][column];

        Scanner input = new Scanner(System.in);

        // fill in the first matrix, which is a two-dimensional array
        System.out.println("Please enter " + row*column + " values for the first matrix.");
        for(int i=0; i<row; i++) {
            for(int j=0; j<column; j++) {
                System.out.print("Please enter the value for [row#" + i + " , column#" + j + "] : ");
                matrix1[i][j] = input.nextInt();
            }
        }

        // fill in the second matrix
        System.out.println("Please enter " + row*column + " values for the second matrix.");
        for(int i=0; i<matrix2.length; i++) {
            for(int j=0; j<matrix2[i].length; j++) {
                System.out.print("Please enter the value for [row#" + i + " , column#" + j + "] : ");
                matrix2[i][j] = input.nextInt();
            }
        }

        // compute the addition result matrix
        for(int i=0; i<row; i++) {
            for(int j=0; j<column; j++) {
                result[i][j] = matrix1[i][j] + matrix2[i][j];
            }
        }

        // print out the result
        System.out.println("The sum matrix of the two matrices is:");
        for(int i=0; i<result.length; i++) {
            for(int j=0; j<result[i].length; j++) {
                System.out.print(result[i][j]+ " " );
            }
            System.out.println(); // print each row in a separate line
        }

        // find the maximum value in the two-dimensional array
        maximum = result[0][0];
        for(int i=0; i<row; i++) {
            for(int j=0; j<column; j++) {
                if(result[i][j]>maximum) { // compare
                    maximum = result[i][j]; // update
                }
            }
        }

        System.out.println("Maximum value in the result matrix is " + maximum);
    }
}