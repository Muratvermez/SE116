/**
 *  A sample solution for Lab#1_3 of SE 116
 *  created by Ilker Korkmaz
 **/

import java.util.Scanner;
public class Lab1_3 {
    public static void main(String[] args) {
        System.out.print("Enter a nonnegative integer: ");
        Scanner scanner= new Scanner (System.in);
        int number=scanner.nextInt();

        int result=1;
        for(int i=1; i<=number; i++) {
            result *= i;
        }

        System.out.println(number +"! = " + result);
    }
}