/**
 *  A sample solution for Lab#1_4 of SE 116
 *  created by Ilker Korkmaz
**/

public class Lab1_4 {
    public static void main(String[] args) {
        int beginValue=1;
        int endValue=7;

        for(int n=beginValue; n<=endValue; n++) {
            int result = 1;
            for (int i = 1; i <= n; i++) {
                result *= i;
            }
            System.out.println(n + "! = " + result);
        }
    }
}