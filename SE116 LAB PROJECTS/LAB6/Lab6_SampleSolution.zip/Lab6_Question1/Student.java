public class Student {
    private int ID;
    private String fullName;
    private double grade;

    public Student() {
        this.ID = 0;
        this.fullName = "Unknown" ;
        this.grade = 0.0;
    }

    public Student(int ID, String fullName, double grade) {
        this.ID = ID;
        this.fullName = fullName;
        this.setGrade(grade);  // "setGrade" will validate the argument value
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public double getGrade() {
        return grade;
    }

    public void setGrade(double grade) {
        if(grade<0.0 || grade >100.0)  // input data validation: grade should fall in the range [0, 100]
            grade = 0.0;

        this.grade = grade;
    }

    public void displayInfo(){
        System.out.println("STUDENT INFO");
        System.out.println("------------");
        System.out.println("ID    : " + getID());
        System.out.println("NAME  : " + getFullName());
        System.out.println("GRADE : " + getGrade());
        System.out.println();
    }
}