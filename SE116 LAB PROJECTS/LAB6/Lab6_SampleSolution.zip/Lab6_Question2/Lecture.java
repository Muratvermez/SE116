import java.util.ArrayList;

public class Lecture {
    private int lectureID;
    private String lectureName;
    private ArrayList<Student> studentList;
    private static int numberOfLectures=0;

    public Lecture() {
        this.lectureID = 0;
        this.lectureName = "Unknown";
        this.studentList = new ArrayList<Student>();
        numberOfLectures++;
    }

    public Lecture(int lecID, String lecName, ArrayList<Student> stdList) {
        this.lectureID = lecID;
        this.lectureName = lecName;
        this.studentList = stdList;
        numberOfLectures++;
    }

    public int getLectureID() {
        return this.lectureID;
    }

    public void setLectureID(int lecID) {
        this.lectureID = lecID;
    }

    public String getLectureName() {
        return this.lectureName;
    }

    public void setLectureName(String lecName) {
        this.lectureName = lecName;
    }

    public ArrayList<Student> getStudentList() {
        return this.studentList;
    }

    public void setStudentList(ArrayList<Student> stdList) {
        this.studentList = stdList;
    }

    public void printData(){
        System.out.println("LECTURE INFO");
        System.out.println("------------");
        System.out.println("ID   : " + getLectureID());
        System.out.println("NAME : " + getLectureName());
        System.out.println("STUDENTS OF THE LECTURE : ");
        System.out.println();
        for(int i=0; i<this.getStudentList().size(); i++) {
            this.getStudentList().get(i).displayInfo();
        }
    }

    public static int getNumberOfLectures(){
        return numberOfLectures;
    }
}
