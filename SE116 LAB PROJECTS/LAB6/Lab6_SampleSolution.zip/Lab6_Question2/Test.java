import java.util.ArrayList;
import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        Scanner scan=new Scanner(System.in);

        Student first = new Student(1, "Erdem", 23.0); // initialized with constant argument values
        Student second = new Student(2, "Nil", 90.0);
        Student third = new Student(3, "Zeki", 21.5);
        Student fourth = new Student(4, "Derya", 75.0);
        Student fifth = new Student(5, "Deniz", 65.0);

        ArrayList<Student> stdList1 = new ArrayList<Student>();

        stdList1.add(first); // the Student reference "first" is added into ArrayList<> object "stdList1"
        stdList1.add(second);
        stdList1.add(third);
        stdList1.add(fourth);
        stdList1.add(fifth);

        System.out.println("Number of lectures instantiated in the program is: "+Lecture.getNumberOfLectures());
        Lecture lec1 = new Lecture(116, "Programming", stdList1);
        System.out.println("Number of lectures instantiated in the program is: "+Lecture.getNumberOfLectures());

        //User will enter the data for the new 5 students and the new lecture
        int tempStdId;
        String tempStdName;
        double tempStdGrade;

        int tempLecID;
        String tempLecName;
        ArrayList<Student> stdList2 = new ArrayList<Student>();

        for(int i=0; i<5; i++){
            System.out.println();
            System.out.println("Please enter the information of the new student#" + (i+1) + " : ");
            System.out.print("ID: ");
            tempStdId=scan.nextInt();
            scan.nextLine(); // '\n' is read here

            System.out.print("Name: ");
            tempStdName=scan.nextLine();

            System.out.print("Grade: ");
            tempStdGrade=scan.nextDouble();

            Student temp = new Student(tempStdId, tempStdName, tempStdGrade);
            stdList2.add(temp);

            System.out.println("Student is registered successfully!");
        }

        System.out.println("Please enter the information of the new lecture : ");
        System.out.print("Lecture ID: ");
        tempLecID=scan.nextInt();
        scan.nextLine(); // '\n' is read here

        System.out.print("Lecture Name: ");
        tempLecName=scan.nextLine();

        Lecture lec2 = new Lecture(tempLecID,tempLecName,stdList2);
        System.out.println("Number of lectures instantiated in the program is: "+Lecture.getNumberOfLectures());

        //Printing information about students passed...
        System.out.println("Students who passed the lecture " + lec1.getLectureID() + " " + lec1.getLectureName()+ " :");

        for(int i=0; i<lec1.getStudentList().size(); i++){
            if(lec1.getStudentList().get(i).getGrade()>=60.0){
                lec1.getStudentList().get(i).displayInfo();
            }
        }

        System.out.println("Students who passed the lecture " + lec2.getLectureID() + " " + lec2.getLectureName()+ " :");

        for(int i=0; i<lec2.getStudentList().size(); i++){
            if(lec2.getStudentList().get(i).getGrade()>=60.0){
                lec2.getStudentList().get(i).displayInfo();
            }
        }

        System.out.println("Number of lectures instantiated in the program is: "+Lecture.getNumberOfLectures());
        System.out.println("Number of lectures instantiated in the program is: "+lec1.getNumberOfLectures());
        System.out.println("Number of lectures instantiated in the program is: "+lec2.getNumberOfLectures());
    }
}