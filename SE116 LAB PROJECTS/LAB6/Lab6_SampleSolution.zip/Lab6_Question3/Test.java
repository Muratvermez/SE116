import java.util.ArrayList;
import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        Scanner scan=new Scanner(System.in);

        Student first = new Student(1, "Erdem", 23.0); // initialized with constant argument values
        Student second = new Student(2, "Nil", 90.0);
        Student third = new Student(3, "Zeki", 21.5);
        Student fourth = new Student(4, "Derya", 75.0);
        Student fifth = new Student(5, "Deniz", 65.0);

        ArrayList<Student> stdList1 = new ArrayList<Student>();

        stdList1.add(first); // the Student reference "first" is added into ArrayList<> object "stdList1"
        stdList1.add(second);
        stdList1.add(third);
        stdList1.add(fourth);
        stdList1.add(fifth);

        ArrayList<Lecture> lectureList = new ArrayList<Lecture>();

        System.out.println("Number of lectures instantiated in the program is: "+Lecture.getNumberOfLectures());
        Lecture lec1 = new Lecture(116, "Programming", stdList1);
        lectureList.add(lec1);
        System.out.println("Number of lectures instantiated in the program is: "+Lecture.getNumberOfLectures());

        //User will enter the data for the new 5 students and the new lecture
        int tempStdId;
        String tempStdName;
        double tempStdGrade;

        int tempLecID;
        String tempLecName;
        ArrayList<Student> stdList2 = new ArrayList<Student>();

        for(int i=0; i<5; i++){
            System.out.println();
            System.out.println("Please enter the information of the new student#" + (i+1) + " : ");
            System.out.print("ID: ");
            tempStdId=scan.nextInt();
            scan.nextLine(); // '\n' is read here

            System.out.print("Name: ");
            tempStdName=scan.nextLine();

            System.out.print("Grade: ");
            tempStdGrade=scan.nextDouble();

            Student temp = new Student(tempStdId, tempStdName, tempStdGrade);
            stdList2.add(temp);

            System.out.println("Student is registered successfully!");
        }

        System.out.println("Please enter the information of the new lecture : ");
        System.out.print("Lecture ID: ");
        tempLecID=scan.nextInt();
        scan.nextLine(); // '\n' is read here

        System.out.print("Lecture Name: ");
        tempLecName=scan.nextLine();

        Lecture lec2 = new Lecture(tempLecID,tempLecName,stdList2);
        lectureList.add(lec2);
        System.out.println("Number of lectures instantiated in the program is: "+Lecture.getNumberOfLectures());

        System.out.println("Let's print the data of the lectures in the lectureList");
        for (int i=0; i<lectureList.size(); i++){
            lectureList.get(i).printData();
        }

        System.out.println("For each lecture in the lectureList, let's find the students who passed:");
        for (int i=0; i<lectureList.size(); i++){
            System.out.println("Students who passed the lecture " + lectureList.get(i).getLectureID() + " " + lectureList.get(i).getLectureName()+ " :");
            for(int j=0; j<lectureList.get(i).getStudentList().size(); j++){
                if(lectureList.get(i).getStudentList().get(j).getGrade()>=60.0){
                    lectureList.get(i).getStudentList().get(j).displayInfo();
                }
            }
        }

        System.out.println("For each lecture, let's find the student with the highest grade:");
        for (int i=0; i<lectureList.size(); i++) {
            Student highestReference = lectureList.get(i).getStudentList().get(0);  // suppose that the first student in the corresponding studentList of the lecture owns the highest grade value
            for (int j = 0; j < lectureList.get(i).getStudentList().size(); j++) {
                if (lectureList.get(i).getStudentList().get(j).getGrade() > highestReference.getGrade()) {
                    highestReference = lectureList.get(i).getStudentList().get(j);
                }
            }
            System.out.println("The student with the highest grade in " + lectureList.get(i).getLectureID() + " " + lectureList.get(i).getLectureName() + " :");
            highestReference.displayInfo();
        }

        System.out.println("For each lecture, let's find the student with the lowest grade:");
        for (int i=0; i<lectureList.size(); i++) {
            Student lowestReference = lectureList.get(i).getStudentList().get(0);  // suppose that the first student in the corresponding studentList of the lecture owns the lowest grade value
            for (int j = 0; j < lectureList.get(i).getStudentList().size(); j++) {
                if (lectureList.get(i).getStudentList().get(j).getGrade() < lowestReference.getGrade()) {
                    lowestReference = lectureList.get(i).getStudentList().get(j);
                }
            }
            System.out.println("The student with the lowest grade in " + lectureList.get(i).getLectureID() + " " + lectureList.get(i).getLectureName() + " :");
            lowestReference.displayInfo();
        }

        System.out.println("For each lecture, let's find the average grade value of the students:");
        for (int i=0; i<lectureList.size(); i++) {
            double sum = 0.0;
            for (int j = 0; j < lectureList.get(i).getStudentList().size(); j++) {
                sum = sum + lectureList.get(i).getStudentList().get(j).getGrade();
            }
            double average=sum/lectureList.get(i).getStudentList().size();
            System.out.printf("The average grade value of the students in " + lectureList.get(i).getLectureID() + " " + lectureList.get(i).getLectureName() + " : %f" , average);
            System.out.println();
        }

        // OR using "foreach"
        for (Lecture aLecture : lectureList) {
            double sum = 0.0;
            for (int j = 0; j < aLecture.getStudentList().size(); j++) {
                sum = sum + aLecture.getStudentList().get(j).getGrade();
            }
            double average = sum / aLecture.getStudentList().size();
            System.out.printf("The average grade value of the students in " + aLecture.getLectureID() + " " + aLecture.getLectureName() + " : %f" , average);
            System.out.println();
        }

        System.out.println("Number of lectures instantiated in the program is: "+Lecture.getNumberOfLectures());
        System.out.println("Number of lectures instantiated in the program is: "+lec2.getNumberOfLectures());
        System.out.println("Number of lectures instantiated in the program is: "+lectureList.get(0).getNumberOfLectures());
    }
}