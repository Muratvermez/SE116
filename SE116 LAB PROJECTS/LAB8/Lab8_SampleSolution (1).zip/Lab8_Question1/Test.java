public class Test {
    public static void main(String [] args) {
       //Mage mage1 = new Mage("Merlin","Male");
       Mage mage2 = new Mage("Morgana","Female");

       Warrior warrior1 = new Warrior("Arthur", "Male");
       // Warrior warrior2 = new Warrior("Lancelot","Male" );
       // Warrior warrior3 = new Warrior("MechWarrior", "Robot");

       mage2.printInfo();
       mage2.attack();
       mage2.attack();
       mage2.printInfo();
       mage2.attack();
       mage2.regeneratePower();
       mage2.attack();
       mage2.printInfo();
       
       System.out.println();
       
       warrior1.printInfo();
       warrior1.attack();
       warrior1.attack();
       warrior1.attack();
       warrior1.regeneratePower();
       warrior1.printInfo();
       warrior1.attack();
       warrior1.printInfo();
    }
}