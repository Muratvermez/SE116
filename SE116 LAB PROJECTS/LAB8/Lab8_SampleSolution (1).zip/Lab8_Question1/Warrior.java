// subclass - child class - derived class
public class Warrior extends Character {
    private int energy; // extra data member

    public Warrior() {  // non-parameterized constructor
        energy = 20;
    }

    public Warrior(String name, String gender) { // parameterized constructor
        super(name, gender);
        energy = 20;
    }

    @Override // @Override ANNOTATION indicates that the following method overrides a superclass method.
    public double calculateDamage() {
        return hitPoint * 1.2;
    }

    @Override
    public void attack() {
        if (energy < 10) // check energy before attacking
            System.out.println("Not enough energy. Get rest...");
        else {
            energy = energy - 10;
            System.out.println("Swinging my sword");
            super.attack();
        }
        System.out.println("Remaining energy: " + energy);
    }
	
    @Override // @Override ANNOTATION indicates that the following method overrides a superclass method.
    public void regeneratePower() {
        rest();
    }

    public void rest() {
        System.out.println("Resting now...");
        this.energy += 20;
		System.out.println("Remaining energy: " + energy);
    }

    @Override
    public void printInfo() {
        super.printInfo();
        System.out.println("Energy: " + energy);
    }
}