import java.util.ArrayList;

public class Player {
    private String name;
    private String password;
    private ArrayList<Character> characters;  // Player "HAS-A" ArrayList of Character

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public ArrayList<Character> getCharacters() {
        return characters;
    }

    public void setCharacters(ArrayList<Character> characters) {
        this.characters = characters;
    }

    public Player() { // non-parameterized constructor
        this.name = "New Player";
        this.password = "qwerty";
        characters = new ArrayList<Character>();
    }

    public Player(String name, String password, ArrayList<Character> characters) { // parameterized constructor
        this.name = name;
        this.password = password;
		this.characters = characters;
    }

    public double calculateTotalDamage() { // returns the total damage of all characters in the list
        double totalDamage = 0;
        for(int i= 0; i < characters.size(); i++) {
            totalDamage += characters.get(i).calculateDamage();
        }
        return totalDamage;
    }

    public void printPlayerInfo() { // prints the information of all characters in the list
        System.out.println("Name: "+ name + " password: "+ password);
        for(int i= 0; i < characters.size(); i++) {
            characters.get(i).printInfo();
        }
    }
}