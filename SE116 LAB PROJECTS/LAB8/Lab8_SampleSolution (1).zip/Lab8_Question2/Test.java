import java.util.ArrayList;

public class Test {
    public static void main(String[] args) {
        // Instantiate various Mage and Warrior objects with parameterized constructors
        Mage mage1 = new Mage("Merlin","Male");
        Mage mage2 = new Mage("Morgana","Female");

        Warrior warrior1 = new Warrior("Arthur", "Male");
        Warrior warrior2 = new Warrior("Lancelot","Male" );
        Warrior warrior3 = new Warrior("MechWarrior", "Robot");

        // Perform some actions on Mage and Warrior objects
        mage1.attack();
        mage1.attack();
        mage1.attack();
        mage1.regeneratePower();
        mage1.attack();
        mage1.printInfo();

        warrior1.printInfo();
        warrior2.attack();
        warrior2.attack();
        warrior2.attack();
        warrior2.regeneratePower();
        warrior2.attack();
        warrior1.printInfo();

        warrior3.printInfo(); // printing information for Warrior object

        // Creating a list of characters
        ArrayList<Character> list1 = new ArrayList<Character>();
        list1.add(mage1);
        list1.add(warrior2);

        // Creating another list of characters
        ArrayList<Character> list2 = new ArrayList<Character>();
        list2.add(mage2);
        list2.add(mage1);

        ArrayList<Character> list3 = new ArrayList<Character>();
        list3.add(mage2);
        list3.add(mage1);
        list3.add(warrior3);

        // Creating new Players using parameterized constructors
        Player p1 = new Player("Erdem", "1234", list1);
        Player p2 = new Player("Levent", "2345", list2);
        Player p3 = new Player("Serhat", "2345", list3);

        // Creating an ArrayList of players to refer to the players in a game
        ArrayList<Player> game = new ArrayList<Player>();
        game.add(p1);
        game.add(p2);
        game.add(p3);

        game.get(0).getCharacters().get(0).attack();  // Who is attacking now?
        game.get(0).getCharacters().get(1).attack();  // Who is attacking now?
        game.get(1).getCharacters().get(1).attack();  // Who is attacking now?
        game.get(2).getCharacters().get(2).attack();  // Who is attacking now?
        
        game.get(1).getCharacters().get(0).regeneratePower(); // Who is performing which action now?
        game.get(0).getCharacters().get(1).regeneratePower(); // Who is performing which action now?
        
        double highestTotalDamage = game.get(0).calculateTotalDamage(); // the highest damage is assigned with total damage of the first player in the list
        int highestTotalDamagePlayerIndex = 0; // the index (or location) of the player with highestTotalDamage
        // iterate over game to find out the player with the highest total damage
        for(int i= 0; i< game.size(); i++) {
            System.out.println("Total damage for player "+ game.get(i).getName()+  " "  +game.get(i).calculateTotalDamage()); //get each players totalDamage and print it

            // find the player with the highest total damage and its index in the list
            if(highestTotalDamage < game.get(i).calculateTotalDamage()) {
                highestTotalDamage =  game.get(i).calculateTotalDamage();
                highestTotalDamagePlayerIndex = i;
            }
        }

        // prints the player with the highest total damage
        System.out.println("Player with highest damage is "+ game.get(highestTotalDamagePlayerIndex).getName());

        // prints information of all players within the game
        System.out.println("-----------------------");
        for(int i= 0; i < game.size(); i++) {
            game.get(i).printPlayerInfo();
            System.out.println("-----------------------");
        }
    }
}