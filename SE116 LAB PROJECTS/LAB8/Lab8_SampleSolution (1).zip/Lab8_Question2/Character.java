// superclass - parent class - base class
public class Character {
	private String name;  // common data members in Character hierarchy
    private int hitPoint;
    private String gender;

	public Character() { // non-parameterized constructor
		this.name = "New Player";
		this.hitPoint = 10;
		this.gender = "Unknown";
	}

	public Character(String name, String gender) { // parameterized constructor
		this.name = name;
		this.hitPoint = 10;
		this.gender = gender;
	}

	public String getGender() {
		return gender;
	}
	
	public void setGender(String gender) {
		this.gender = gender;
	}
    
	public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getHitPoint() {
        return hitPoint;
    }

    public double calculateDamage() {
		return hitPoint;
    }

    public void attack() {
		System.out.println("Attacking... " + "Damage done is " + calculateDamage());
    }

    public void regeneratePower() { 
		System.out.println("Regenerating power"); 
	}

    public void printInfo() {
        System.out.println("Name: " + name + " hitPoint: " + hitPoint + " Gender: " + gender);
    }
}// end of class Character