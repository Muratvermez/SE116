// subclass - child class - derived class
public class Mage extends Character {
    private int mana; // extra data member
    
	public Mage() { // non-parameterized constructor
        this.mana = 10;
    }

    public Mage(String name, String gender) { // parameterized constructor
        super(name, gender);
        this.mana = 10;
    }

    @Override // @Override ANNOTATION indicates that the following method overrides a superclass method.
    public double calculateDamage() {
        return getHitPoint() * 0.8;
    }

    @Override
    public void attack() {
        if (mana < 5) // check mana before attacking
            System.out.println("Not enough mana. Drink potion...");
        else {
            mana = mana - 5;
            System.out.println("Casting spell...");
            super.attack();
        }
        System.out.println("Remaining Mana: " + mana);

    }
    @Override
    public void regeneratePower() {
        drinkPotion();
    }

    public void drinkPotion() {
        System.out.println("Drinking potion...");
        this.mana += 10;
        System.out.println("Remaining Mana: " + mana);
    }

    public void printInfo() {
        super.printInfo();
        System.out.println("Mana: " + mana);
    }
}