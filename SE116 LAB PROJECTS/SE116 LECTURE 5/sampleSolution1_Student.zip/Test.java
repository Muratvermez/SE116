/*
* Author: Ilker Korkmaz
*/

import java.util.ArrayList;
import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        String tempName;
        int tempID;
        int tempAge;

        ArrayList<Student> myArrayList = new ArrayList<Student>(); // an instance of ArrayList that will contain Student references

        Scanner myInputObject = new Scanner(System.in); // a Scanner object is created to obtain (read) input from the keyboard

        System.out.println("Initially, there are " + myArrayList.size() + " students in myArrayList...");

        // Let's instantiate 4 new Student objects
        Student s1=new Student();
        Student s2=new Student();
        Student s3=new Student();
        Student s4=new Student();
        // Let's add the references of the students into myArrayList
        myArrayList.add(s1);
        myArrayList.add(s2);
        myArrayList.add(s3);
        myArrayList.add(s4);
        System.out.println("Then, 4 student references are added into myArraylist...");

        for(int i=0; i<myArrayList.size(); i++) {
            System.out.println("The initial values of " + i +". Student object in myArrayList");
            System.out.println("Name: " + myArrayList.get(i).getName());
            System.out.println("ID: " + myArrayList.get(i).getID());
            System.out.println("Age: " + myArrayList.get(i).getAge());
        }

        System.out.println();

        System.out.println("Let's now obtain the values to be set for each content of myArrayList");
        for(int i=0; i<myArrayList.size(); i++) {
            System.out.print("Enter a name: ");
            tempName = myInputObject.next();
            System.out.print("Enter an ID: ");
            tempID = myInputObject.nextInt();
            System.out.print("Enter an age: ");
            tempAge = myInputObject.nextInt();

            System.out.println();

            // set the instance variables of the object with the values entered
            myArrayList.get(i).setName(tempName);
            myArrayList.get(i).setID(tempID);
            myArrayList.get(i).setAge(tempAge);
        }

        System.out.println("Finally, let's display the information of the contents of myArrayList:");
        for(int i=0; i<myArrayList.size(); i++) {
            System.out.println("Name: " + myArrayList.get(i).getName());
            System.out.println("ID: " + myArrayList.get(i).getID());
            System.out.println("Age: " + myArrayList.get(i).getAge());
            System.out.println();
        }

        System.out.println("We can also display the data of each content in ArrayList using the corresponding method:");
        for(int i=0; i<myArrayList.size(); i++) {
            myArrayList.get(i).display();
            System.out.println();
        }

        System.out.println("Let's instantiate a Student object using the constructor with no arguments...");
        Student ref1 = new Student();

        System.out.println("Let's instantiate a Student object using the constructor with three arguments...");
        Student ref2 = new Student("Kaya", 1234567, 20);

        System.out.println("Let's instantiate a Student object using the constructor with one argument..");
        Student ref3 = new Student(ref2);

        System.out.println("Let's display the information of the last 3 students:");
        ref1.display();
        ref2.display();
        ref3.display();
    } // end of main
} // end of class Test