import java.util.ArrayList;
import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        String tempName;
        int tempID;
        int tempAge;

        ArrayList<Student> myArrayList = new ArrayList<Student>(); // an object (instance) of class ArrayList that will contain Student references

        Scanner myInputObject = new Scanner(System.in); // a Scanner object is created to obtain (read) input from the keyboard

        System.out.println("Initially, there are " + myArrayList.size() + " Student references in myArrayList...");

        // Let's instantiate 4 new Student objects
        Student s1=new Student();
        Student s2=new Student();
        Student s3=new Student();
        Student s4=new Student();
        // Let's add the references of the students into myArrayList
        myArrayList.add(s1);
        myArrayList.add(s2);
        myArrayList.add(s3);
        myArrayList.add(s4);
        System.out.println("Then, 4 Student references are added into myArraylist...");

        for(int i=0; i<myArrayList.size(); i++) {
            System.out.println("The initial information of " + i +". Student reference in myArrayList");
            System.out.println("Name: " + myArrayList.get(i).getName());
            System.out.println("ID: " + myArrayList.get(i).getID());
            System.out.println("Age: " + myArrayList.get(i).getAge());
        }

        System.out.println();

        System.out.println("Let's now obtain the values to be set for each content of myArrayList");
        for(int i=0; i<myArrayList.size(); i++) {
            System.out.print("Enter a name: ");
            tempName = myInputObject.next();
            System.out.print("Enter an ID: ");
            tempID = myInputObject.nextInt();
            System.out.print("Enter an age: ");
            tempAge = myInputObject.nextInt();

            System.out.println();

            // set the instance variables of the object with the values entered
            myArrayList.get(i).setName(tempName);
            myArrayList.get(i).setID(tempID);
            myArrayList.get(i).setAge(tempAge);
        }

        System.out.println("Finally, let's display the information of the contents of myArrayObject:");
        for(int i=0; i<myArrayList.size(); i++) {
            System.out.println("Name: " + myArrayList.get(i).getName());
            System.out.println("ID: " + myArrayList.get(i).getID());
            System.out.println("Age: " + myArrayList.get(i).getAge());
            System.out.println();
        }

        System.out.println("We can also display the information of each reference available in myArrayList using the corresponding method:");
        for(int i=0; i<myArrayList.size(); i++) {
            myArrayList.get(i).display();
            System.out.println();
        }
    } // end of main
}