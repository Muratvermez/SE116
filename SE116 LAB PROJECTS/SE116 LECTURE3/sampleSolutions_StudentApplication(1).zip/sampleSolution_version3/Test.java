import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        String tempName;
        int tempID;
        int tempAge;

        Student[] myArrayObject = new Student[4]; // an array of 4 Student references

        Scanner myInputObject = new Scanner(System.in); // a Scanner object is created to obtain (read) input from the keyboard

        System.out.println("The initial values of the contents of the array:");
        for(int i=0; i<myArrayObject.length; i++){
            System.out.println(myArrayObject[i]);
        }

        for(int i=0; i<myArrayObject.length; i++){
            myArrayObject[i]=new Student(); // for each reference of the array a new Student object is instantiated
        }

        for(int i=0; i<myArrayObject.length; i++) {
            System.out.println("The initial values of the object referred by myArrayObject[" + i + "]:");
            System.out.println("Name: " + myArrayObject[i].getName());
            System.out.println("ID: " + myArrayObject[i].getID());
            System.out.println("Age: " + myArrayObject[i].getAge());
        }

        System.out.println();

        System.out.println("Let's now obtain the values to be set for each content of myArrayObject");
        for(int i=0; i<myArrayObject.length; i++) {
            System.out.print("Enter a name: ");
            tempName = myInputObject.next();
            System.out.print("Enter an ID: ");
            tempID = myInputObject.nextInt();
            System.out.print("Enter an age: ");
            tempAge = myInputObject.nextInt();

            System.out.println();

            // set the instance variables of the object with the values entered
            myArrayObject[i].setName(tempName);
            myArrayObject[i].setID(tempID);
            myArrayObject[i].setAge(tempAge);
        }

        System.out.println("Finally, let's display the information of the contents of myArrayObject:");
        for(int i=0; i<myArrayObject.length; i++) {
            System.out.println("Name: " + myArrayObject[i].getName());
            System.out.println("ID: " + myArrayObject[i].getID());
            System.out.println("Age: " + myArrayObject[i].getAge());
            System.out.println();
        }

        System.out.println("We can also display the information of each reference available in myArrayObject using the corresponding method:");
        for(int i=0; i<myArrayObject.length; i++) {
            myArrayObject[i].display();
            System.out.println();
        }
    } // end of main
}