import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        String tempName;
        int tempID;
        int tempAge;

        Student myObject = new Student(); // an instance (object) of a Student is instantiated (created) here

        Scanner myInputObject = new Scanner(System.in); // a Scanner object is created to obtain (read) input from the keyboard

        System.out.println("The initial values of the instance variables of the object:");
        System.out.println("Name: " + myObject.getName());
        System.out.println("ID: " + myObject.getID());
        System.out.println("Age: " + myObject.getAge());

        System.out.println();

        System.out.println("Let's now obtain the values to be set in the instance variables");
        System.out.print("Enter a name: ");
        tempName = myInputObject.next();
        System.out.print("Enter an ID: ");
        tempID = myInputObject.nextInt();
        System.out.print("Enter an age: ");
        tempAge = myInputObject.nextInt();

        // set the instance variables of the object with the values entered
        myObject.setName(tempName);
        myObject.setID(tempID);
        myObject.setAge(tempAge);

        System.out.println();

        System.out.println("Finally, let's display the values of the instance variables of the object:");
        System.out.println("Name: " + myObject.getName());
        System.out.println("ID: " + myObject.getID());
        System.out.println("Age: " + myObject.getAge());

        System.out.println();

        System.out.println("We can also display the data of the object using the corresponding method:");
        myObject.display();
    } // end of main
} // end of class Test