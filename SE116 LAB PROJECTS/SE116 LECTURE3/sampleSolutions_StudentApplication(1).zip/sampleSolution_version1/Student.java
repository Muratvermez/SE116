/*
* Author: Ilker Korkmaz
* Source code file name: Student.java
* The class Student contains three non-static data members (instance variables) and corresponding methods to set and get their values. The class also contains a method, named display, to print out the information.
*/

import java.util.Scanner;

//declaration of class Student
public class Student{
    /*
    The fields (data members) can be specified as private/public.
    The concept of encapsulation (information hiding): The instance variables that should be hidden are declared with the keyword private.
	The access modifier (access specifier) private allows the corresponding item to be accessible in class only.
    The access modifier (access specifier) public allows the corresponding item to be accessible everywhere.
	The methods that should be accessible out of the class are declared with the keyword public.
    */

    private String name;  // non-static data members (instance variables)
    private int ID;
    private int age;

    // Mutator methods set (modify) the values of the data members.
    // Accessor methods return (retrieve) the values of the data members.

    public void setName(String myName){ // setName is a mutator method
        name=myName; // the following is also OK: this.name=myName;
    }

    public void setID(int myID){ // myID parameter is a local variable of setID method
        /*
        if(myID<=0){ // validation mechanism for the argument value
            myID=1;
        }
        */
        this.ID=myID; // the following is also OK: ID=myID;

        return;
    }

    public void setAge(int myAge){ // setAge method sets the age in the object
        /*
        if(myAge<0){ // validation mechanism
            myAge=0;
        }
        */
        age=myAge; // store myAge value in age instance variable

        // return;
    }

    public String getName() { // getName is an accessor method. An accessor method does not modify the data members.
        return name;
    }

    public int getID() {
        return ID;
    }

    public int getAge() { // getAge method returns the age value of the object
        return age; // the value of age of the object will be returned to the caller of getAge method
    }

    public void display() { // displays the information (data) of the object
        System.out.println("The student information:");
        System.out.println( "Name: " + getName() );  // The following is also OK: System.out.println( "Name: " + name );
        System.out.println( "ID: " + getID() );
        System.out.println( "Age: " + getAge() );
    }

    public static void main(String[] args) { // In fact, main method may be put in a separate driver/test class
        String tempName;
        int tempID;
        int tempAge;

        Student myObject = new Student(); // an instance (object) of a Student is instantiated (created) here

        Scanner myInputObject = new Scanner(System.in); // a Scanner object is created to obtain (read) input from the keyboard

        System.out.println("The initial values of the instance variables of the object:");
        System.out.println( "Name: " + myObject.getName() );
        System.out.println( "ID: " + myObject.getID() );
        System.out.println( "Age: " + myObject.getAge() );

        System.out.println();

        System.out.println("Let's now obtain the values to be set in the instance variables");
        System.out.print("Enter a name: ");
        tempName=myInputObject.next();
        System.out.print("Enter an ID: ");
        tempID=myInputObject.nextInt();
        System.out.print("Enter an age: ");
        tempAge=myInputObject.nextInt();

        // set the instance variables of the object with the values entered
        myObject.setName(tempName);
        myObject.setID(tempID);
        myObject.setAge(tempAge);

        System.out.println();

        System.out.println("Finally, let's display the values of the instance variables of the object:");
        System.out.println( "Name: " + myObject.getName() );
        System.out.println( "ID: " + myObject.getID() );
        System.out.println( "Age: " + myObject.getAge() );

        System.out.println();

        System.out.println("We can also display the data of the object using the corresponding method:");
        myObject.display();
    } // end of main
} // end of class Student
