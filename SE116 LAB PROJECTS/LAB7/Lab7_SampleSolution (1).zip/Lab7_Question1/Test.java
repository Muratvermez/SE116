import java.util.Scanner;
public class Test {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        String tempName;
        int tempAge;
        int tempLegs;

        //Filling the information for an Animal object...
        System.out.print("Please enter a name for Animal object: ");
        tempName=scan.nextLine();
        System.out.print("Please enter an age value for Animal object: ");
        tempAge=scan.nextInt();
        System.out.print("Please enter number of legs for Animal object: ");
        tempLegs=scan.nextInt();
        scan.nextLine();

        Animal animalRef=new Animal(tempName,tempAge,tempLegs); //Creating an Animal object using parameterized constructor...

        System.out.println();

        //Filling the information for a Dog object...
        System.out.print("Please enter a name for Dog object: ");
        tempName=scan.nextLine();
        System.out.print("Please enter an age value for Dog object: ");
        tempAge=scan.nextInt();
        System.out.print("Please enter number of legs for Dog object: ");
        tempLegs=scan.nextInt();
        scan.nextLine();

        Dog dogRef=new Dog(tempName,tempAge,tempLegs);	//Creating a Dog object using parameterized constructor...

        System.out.println();

        //Filling the information for a Duck object...
        System.out.print("Please enter a name for a Duck: ");
        tempName=scan.nextLine();
        System.out.print("Please enter an age value for a Duck: ");
        tempAge=scan.nextInt();
        System.out.print("Please enter number of legs for a Duck: ");
        tempLegs=scan.nextInt();
        scan.nextLine();
        Duck duckRef=new Duck(tempName,tempAge,tempLegs);	//Creating a Duck object using parameterized constructor...

        animalRef.printAllData();
        dogRef.printAllData();
        duckRef.printAllData();

        scan.close();
    }

} // end of class Test
