 /*
    class Animal will be the superclass (or base class or parent class)
 */
 
public class Animal {
     protected String name;  /* using the access modifier protected, data members are accessible in class scope and subclass' scope. */
     protected int age;
     protected int numberOfLegs;

     public Animal() {    // non-parameterized constructor
         this.name = "Unknown";
         age = 0;
         this.numberOfLegs = 0;
     }

     public Animal(String name, int age, int noOfLegs) {    // parameterized constructor
         this.setName(name);
         setAge(age);
         setNoOfLegs(noOfLegs);
     }

     public String getName() {	/* Accessor methods return (retrieve) the values of the data members */
         return name;
     }

     public void setName(String name) {	 /* Mutator methods set (modify) the values of the data members */
         this.name = name;
     }

     public int getAge() {
         return this.age;
     }

     public void setAge(int age) {
         this.age = age;
     }

     public int getNoOfLegs() {
         return numberOfLegs;
     }

     public void setNoOfLegs(int noOfLegs) {
         this.numberOfLegs = noOfLegs;
     }

     public void printVoice() {
         System.out.println("In the future, the method printVoice will display the voice of a subclass of the class Animal");
     }

     public void printAllData() {
         System.out.println();
         System.out.println("ANIMAL INFO");
         System.out.println("-----------");
         System.out.println("NAME           : " + name);    // OR: System.out.println("NAME        : " + getName() );
         System.out.println("AGE            : " + age);
         System.out.println("NUMBER OF LEGS : " + numberOfLegs);
         printVoice();
     }
 } // end of class Animal
