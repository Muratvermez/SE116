/*
   class Duck "is a" subclass (or derived class or child class) of class Animal
*/

public class Duck extends Animal{ // the keyword "extends" is used for "INHERITANCE" ("IS-A relationship")
    public void printVoice() { // the method printVoice is overridden here
        System.out.println("QUACK!");
    }
    public Duck(String duckName, int duckAge, int duckNumberOfLegs) { // parameterized constructor
        super(duckName, duckAge, duckNumberOfLegs);
    }
} // end of class Duck
