/*
   class Dog "is a" subclass (or derived class or child class) of class Animal
*/

public class Dog extends Animal { // the keyword "extends" is used for "INHERITANCE" ("IS-A relationship")
    public void printVoice() { // the method printVoice is overridden here
        System.out.println("WOOF!");
    }
    public Dog(String dogName, int dogAge, int dogNumberOfLegs) { // parameterized constructor
        super(dogName, dogAge, dogNumberOfLegs);
    }
} // end of class Dog
