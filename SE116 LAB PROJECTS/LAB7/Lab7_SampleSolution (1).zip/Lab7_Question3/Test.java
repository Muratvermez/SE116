import java.util.ArrayList; // Library to use the class ArrayList
import java.security.SecureRandom; // Library to use the class SecureRandom
import java.util.Scanner; // Library to use the class Scanner

public class Test {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in); // A Scanner object is created using parameterized constructor

        ArrayList<Animal> zoo = new ArrayList<Animal>(); // An ArrayList of Animal is created using default constructor

        SecureRandom randomNumbers = new SecureRandom(); // A SecureRandom object is created using default constructor

        String tempName;
        int tempAge;
        int tempLegs;
        int tempBeard;
        int aRandomValue;

        for (int i = 0; i < 10; i++) {
            System.out.println();
            aRandomValue = 1 + randomNumbers.nextInt(3); // Pick a random integer from 1 to 3
            switch (aRandomValue) {
                case 1:  // If the random value is 1, you will create a Dog object
                    System.out.print("Please enter a name for a Dog: ");
                    tempName = scan.nextLine();
                    System.out.print("Please enter an age for a Dog: ");
                    tempAge = scan.nextInt();
                    System.out.print("Please enter number of legs for a Dog: ");
                    tempLegs = scan.nextInt();
                    scan.nextLine();
                    Dog dogRef = new Dog(tempName, tempAge, tempLegs); // Creation of the Dog object using parameterized constructor
                    zoo.add(dogRef); // Using add method provided by the ArrayList, a Dog reference is added into the list.
                    break;

                case 2: // If the random value is 2, you will create a Duck object
                    System.out.print("Please enter a name for a Duck: ");
                    tempName = scan.nextLine();
                    System.out.print("Please enter an age for a Duck: ");
                    tempAge = scan.nextInt();
                    System.out.print("Please enter number of legs for a Duck: ");
                    tempLegs = scan.nextInt();
                    scan.nextLine();
                    Duck duckRef = new Duck(tempName, tempAge, tempLegs); // Creation of the Duck object using parameterized constructor
                    zoo.add(duckRef);    // Using add method provided by the ArrayList, a Duck reference is added into the list.
                    break;

                case 3: // If the random value is 3, you will create a Goat object
                    System.out.print("Please enter a name for a Goat: ");
                    tempName = scan.nextLine();
                    System.out.print("Please enter an age for a Goat: ");
                    tempAge = scan.nextInt();
                    System.out.print("Please enter number of legs for a Goat: ");
                    tempLegs = scan.nextInt();
                    System.out.print("Please enter the length of beard for a Goat: ");
                    tempBeard = scan.nextInt();
                    scan.nextLine();
                    Goat goatRef = new Goat(tempName, tempAge, tempLegs, tempBeard); // Creation of the Goat object using parameterized constructor
                    zoo.add(goatRef);    // Using add method provided by the ArrayList, a Goat reference is added into the list.
                    break;
            } // end of switch statement
        } // end of for loop

        System.out.println();
        System.out.println("Let's display all animals in the zoo:");
        for (Animal anyKindOfAnimal : zoo)
            anyKindOfAnimal.printAllData();

        System.out.println();
        System.out.println("Let's find and display the animal with greatest age value:");
        Animal oldest = zoo.get(0); // Suppose that the first animal in the list is the oldest one.
        for (int i = 0; i < zoo.size(); i++)
            if (oldest.getAge() < zoo.get(i).getAge()) // compare the age values
                oldest = zoo.get(i);

        oldest.printAllData();

        System.out.println();
        System.out.println("Let's find and display the animals with 2 legs (if available in the zoo) :");
        boolean isThereAnySuchAnimal = false;
        for (Animal element : zoo) {
            if (element.getNoOfLegs() == 2) {
                element.printAllData();
                isThereAnySuchAnimal = true;
            }
        }
        if(!isThereAnySuchAnimal)
            System.out.println("There is no animal with 2 legs in the zoo...");

        System.out.println();
        System.out.print("Now, let's compute and print out the average age value of all animals in the zoo : ");
        double sum=0.0;
        for(int i=0; i<zoo.size(); i++)
            sum += zoo.get(i).getAge();

        double average = sum/zoo.size();
        System.out.println(average);

        scan.close();
    } // end of main
} // end of class Test