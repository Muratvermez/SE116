/*
   class Goat "is a" subclass (or derived class or child class) of class Animal
*/

public class Goat extends Animal{ // the keyword "extends" is used for "INHERITANCE" ("IS-A relationship")

    // Remember that a subclass inherits all the members from its superclass.

    private int lengthOfBeard; // extra data member

    public void setLengthOfBeard(int length) { // extra set method
        this.lengthOfBeard = length;
    }

    public int getLengthOfBeard() {  // extra get method
        return lengthOfBeard;
    }

    public Goat(String goatName, int goatAge, int goatNumberOfLegs, int goatLengthOfBeard) { // parameterized constructor
        super(goatName, goatAge, goatNumberOfLegs); // call the parameterized constructor of the superclass
        this.setLengthOfBeard(goatLengthOfBeard);
    }

    public void printVoice() { // the method printVoice is overridden here
        System.out.println("BAAAAA!");
    }

    public void printAllData() { // the method printAllData is overridden here
        super.printAllData(); // // call the method printAllData of the superclass
        System.out.println("LENGTH OF BEARD: " + lengthOfBeard);
    }
} // end of class Goat
