// concrete class Computer
// relationship is "relalization": Computer realizes Advertisable
public class Computer implements Advertisable {
    private String screenResolution;
    private int ramSize;
    private int hardDriveSize;
    private String operatingSystem;

    //parameterized constructor
    public Computer(String screenResolution, int ramSize, int hardDriveSize, String operatingSystem) {
        setScreenResolution(screenResolution);
        setRamSize(ramSize);
        setHardDriveSize(hardDriveSize);
        setOperatingSystem(operatingSystem);
    }

    //getters and setters of corresponding variables
    public String getScreenResolution() {
        return screenResolution;
    }
    public void setScreenResolution(String screenResolution) {
        this.screenResolution = screenResolution;
    }
    public int getRamSize() {
        return ramSize;
    }
    public void setRamSize(int ramSize) {
        this.ramSize = ramSize;
    }
    public int getHardDriveSize() {
        return hardDriveSize;
    }
    public void setHardDriveSize(int hardDriveSize) {
        this.hardDriveSize = hardDriveSize;
    }
    public String getOperatingSystem() {
        return operatingSystem;
    }
    public void setOperatingSystem(String operatingSystem) {
        this.operatingSystem = operatingSystem;
    }
	
	// concrete class Computer defines the abstract method of interface Advertisable
    @Override  
    public void advertise() {
        System.out.println("-----------COMPUTER------------");
        System.out.println("OPERATING SYSTEM: " + getOperatingSystem());
        System.out.println("SCREEN RESOLUTION: " + getScreenResolution());
        System.out.println("RAM SIZE:  " + getRamSize());
        System.out.println("HARD DRIVE SIZE: " + getHardDriveSize());
    }
}