// concrete class AdvertOwner
// relationship is "relalization": AdvertOwner realizes Advertisable
public class AdvertOwner implements Advertisable {
    private String fullName;
    private final int ADVERT_OWNER_ID; // naming convention: final variable identifiers are written using uppercase letters
    private String contactNumber;

    //parameterized constructor
    public AdvertOwner(String fN, int iD, String cN) {
        setFullName(fN);
        ADVERT_OWNER_ID = iD;
        setContactNumber(cN);
    }

    //getters and setters of corresponding variables
    public int getADVERT_OWNER_ID() {
        return ADVERT_OWNER_ID;
    }
    public String getContactNumber() {
        return contactNumber;
    }
    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }
    public String getFullName() {
        return fullName;
    }
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }
	
	// concrete class AdvertOwner defines the abstract method of interface Advertisable
    @Override
    public void advertise() {
        System.out.println("-----------ADVERTOWNER------------");
        System.out.println("ID: " + getADVERT_OWNER_ID());
        System.out.println("NAME: " + getFullName());
        System.out.println("CONTACT NUMBER: " + getContactNumber());
    }
}