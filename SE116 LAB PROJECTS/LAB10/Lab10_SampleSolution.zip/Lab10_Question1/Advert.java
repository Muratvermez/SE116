// concrete class Advert
// relationship is "relalization": Advert realizes Advertisable
public class Advert implements Advertisable {
    private final int ADVERT_NO; // naming convention: final variable identifiers are written using uppercase letters
    private AdvertOwner advertOwner;
    private Computer computer;
    private int price;

    //parameterized constructor
    public Advert(int advertNo, AdvertOwner advertOwner, Computer computer, int price) {
        ADVERT_NO = advertNo;
        setAdvertOwner(advertOwner);
        setComputer(computer);
        setPrice(price);
    }

    //getters and setters of corresponding variables
    public int getADVERT_NO() {
        return ADVERT_NO;
    }
    public AdvertOwner getAdvertOwner() {
        return advertOwner;
    }
    public void setAdvertOwner(AdvertOwner advertOwner) {
        this.advertOwner = advertOwner;
    }
    public Computer getComputer() {
        return computer;
    }
    public void setComputer(Computer computer) {
        this.computer = computer;
    }
    public int getPrice() {
        return price;
    }
    public void setPrice(int price) {
        if(price < 0) { //check whether the price is negative or not and set it to 0 is it is negative
            price = 0;
        }
        this.price = price;
    }
    
	// concrete class Advert defines the abstract method of interface Advertisable
    @Override
	public void advertise(){
        System.out.println("#######################################ADVERT############################################");
        System.out.println("ADVERT NO: " + getADVERT_NO());
        getComputer().advertise();
        System.out.println("PRICE TO BUY THE COMPUTER: " + getPrice());
        getAdvertOwner().advertise();
        System.out.println("#########################################################################################");
    }
}