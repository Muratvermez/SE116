import java.util.ArrayList;
import java.util.Scanner;

// class Test demonstrates an online shopping system simulation
public class Test {
    public static void main(String[] args) {
        Scanner scan= new Scanner(System.in);

        ArrayList<AdvertOwner> advertOwners = new ArrayList<AdvertOwner>(); // create array list of advert owners and fill it
        advertOwners.add(new OnlineRetailer("Hepsi Burada", 1, "555-8214", "https://www.hepsiburada.com"));
        advertOwners.add(new OnlineRetailer("Gitti Gidiyor", 4, "555-7214", "https://www.gittigidiyor.com"));
        advertOwners.add(new OnlineRetailer("Amazon", 2, "555-1214", "https://www.amazon.com"));
        advertOwners.add(new ComputerOwner("Levent Tolga Eren", 3, "455-3214", "Research Asistant"));
        advertOwners.add(new ComputerOwner("İlker Korkmaz", 5, "555-4567", "Academician"));
        advertOwners.add(new ComputerOwner("Kaya Oğuz", 6, "555-5555", "Academician"));

        ArrayList<Computer> computerList = new ArrayList<Computer>();// create array list of computers and fill it
        computerList.add(new Computer("1280*720", 8, 500, "Linux"));
        computerList.add(new Computer("1280*720", 8, 500, "Linux"));
        computerList.add(new Computer("1920*1080", 12, 750, "Windows"));
        computerList.add(new Computer("1920*1080", 4, 250, "Windows"));
        computerList.add(new Computer("2560*1440", 4, 250, "Windows"));
        computerList.add(new Computer("3840*2160", 16, 1000, "MacOS"));
        computerList.add(new Computer("7680*4320", 16, 1000, "MacOS"));
        computerList.add(new Computer("1920*1080", 12, 2000, "MacOS"));
        computerList.add(new Computer("1920*1080", 12, 2000, "MacOS"));

        ArrayList<Advert> adverts = new ArrayList<Advert>(); // create array list of adverts and fill it
        adverts.add(new Advert(1, advertOwners.get(0), computerList.get(0), 1500));
        adverts.add(new Advert(2, advertOwners.get(1), computerList.get(1), 1600));
        adverts.add(new Advert(3, advertOwners.get(2), computerList.get(2), 1300));
        adverts.add(new Advert(4, advertOwners.get(3), computerList.get(3), 1550));
        adverts.add(new Advert(5, advertOwners.get(4), computerList.get(4), 2000));
        adverts.add(new Advert(6, advertOwners.get(1), computerList.get(5), 2500));
        adverts.add(new Advert(7, advertOwners.get(2), computerList.get(6), 4000));
        adverts.add(new Advert(8, advertOwners.get(0), computerList.get(7), 2750));
        adverts.add(new Advert(9, advertOwners.get(5), computerList.get(8), 2750));


        ArrayList<String> screenResolution = new ArrayList<String>(); // array list to keep the screen resolution values of computers
        ArrayList<Integer> ramSize = new ArrayList<Integer>();// array list to keep the ram sizes of computers

        String temp;
        int tempF;
        int tempNo;
        int choice = 0;

        while(true) { // iterate in while loop until user wants to exit
            menu();
            boolean loopCondition = true;
            do {
                try { // exception handling mechanism to handle with undesired input attempts
                    choice = Integer.parseInt(scan.nextLine());
                    loopCondition = false;
                } catch (Exception e) {
                    System.err.println("Exception..."+ e.getMessage()); // advertise the reason of exception
                    System.err.println("Enter a number... Press 1 or 2 or 3 ...");
                }
            } while(loopCondition);

            switch(choice){
                case 1: // ask user to enter ram size and screen resolution  value of a computer
                    System.out.println("Please enter the screen resolution properties using the following format: x*y (such as 1920*1080).\nYou can enter different properties each in a new line. Enter -1 to stop adding new properties:");
                    temp = scan.nextLine();
                    while(!temp.equals("-1")) { // take value until user enters -1
                        screenResolution.add(temp);
                        temp = scan.nextLine();
                    }

                    System.out.println("Please enter the ram size you wish. You can enter additional ram sizes each separated by a space character. Enter -1 to stop adding new ram sizes:");
                    tempF = scan.nextInt();
                    while(tempF!=-1) {// take value until user enters -1
                        ramSize.add(tempF);
                        tempF = scan.nextInt();
                    }
                    scan.nextLine();

                    System.out.println("Searching..........");
                    for(int i=0; i<adverts.size(); i++) { // search the previously entered input for given parameters
                        //SCREEN RESOLUTION
                        for(int j=0; j<screenResolution.size(); j++) {
                            //RAM SIZE
                            for(int k=0; k<ramSize.size(); k++) {
                                if(adverts.get(i).getComputer().getScreenResolution().equals(screenResolution.get(j)) && adverts.get(i).getComputer().getRamSize()== ramSize.get(k) ){
                                    adverts.get(i).advertise();
                                }
                            }
                        }
                    }

                    System.out.println("Please enter the corresponding ADVERT NO to filter the computer you want to buy: ");
                    tempNo = Integer.parseInt(scan.nextLine());

                    for(int i=0; i<adverts.size(); i++) { // get the advert with given advert number
                        if(adverts.get(i).getADVERT_NO() == tempNo) {
                            adverts.get(i).advertise();
                        }
                    }

                    System.out.println("Press any key to return to Menu....");
                    scan.nextLine();
                    break;
                case 2:
                    System.out.println("Please enter the full name of the advert owner: ");
                    temp=scan.nextLine();
                    boolean check=false;
                    for(int i=0; i<adverts.size(); i++) { // search the previously entered input for given online retail store parameter
                        if(adverts.get(i).getAdvertOwner().getFullName().equals(temp)) {
                            adverts.get(i).advertise();
                            check=true;
                        }
                    }
                    if(!check) {
                        System.out.println("Found nothing....");
                        break;
                    }

                    System.out.println("Please enter the corresponding ADVERT NO to filter the computer you want to buy: ");
                    tempNo = Integer.parseInt(scan.nextLine());

                    for(int i=0; i< adverts.size(); i++) { // get the advert with given advert number
                        if(adverts.get(i).getADVERT_NO() == tempNo) {
                            adverts.get(i).advertise();
                        }
                    }

                    System.out.println("Press any key to return to Menu....");
                    scan.nextLine();
                    break;
                case 3:
                    System.out.println("Exiting...");
                    System.exit(0);
                default:
                    System.out.println("Wrong Entry...."); // warn the user if he/she enters a value which is not an option in menu
            }
        }
    }

    public static void menu(){ // method to show the options
        System.out.println("<<<<<<<ONLINE SHOPPING SEARCH PROGRAM>>>>>>>" );
        System.out.println("PRESS 1 to search for a computer by the properties you seek" );
        System.out.println("PRESS 2 to search for a computer by checking an advert owner" );
        System.out.println("PRESS 3 to quit" );
        System.out.println("\nPlease enter your choice to continue..." );
    }
}
