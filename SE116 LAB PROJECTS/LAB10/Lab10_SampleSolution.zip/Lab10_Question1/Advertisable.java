// interface to be implemented by other classes
public interface Advertisable {
    /* public abstract */ void advertise();
}
