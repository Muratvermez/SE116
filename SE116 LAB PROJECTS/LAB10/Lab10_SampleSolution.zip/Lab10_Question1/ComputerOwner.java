// concrete class ComputerOwner
// relationship is "is-a" (inheritance) : ComputerOwner "is-a" AdvertOwner
public class ComputerOwner extends AdvertOwner {
    private String occupation;

    //parameterized constructor
    public ComputerOwner(String fN, int iD, String cN, String job) {
        super(fN, iD, cN);// set the corresponding values of constructor of parent class
        setOccupation(job);
    }

    //getter
    public String getOccupation() {
        return occupation;
    }

    //setter
    public void setOccupation(String job) {
        this.occupation = job;
    }
	
	// concrete subclass ComputerOwner re-defines the method of its concrete superclass AdvertOwner
    @Override
    public void advertise() {
        super.advertise();
        System.out.println("OCCUPATION: " + getOccupation());
    }
}