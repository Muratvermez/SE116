// concrete class OnlineRetailer
// relationship is "is-a" (inheritance) : OnlineRetailer "is-a" AdvertOwner
public class OnlineRetailer extends AdvertOwner {
    private String webAdress;

    //parameterized constructor
    public OnlineRetailer(String fN, int iD, String cN, String webAdress) {
        super(fN, iD, cN); // set the corresponding values of constructor of parent class
        setWebAdress(webAdress);
    }

    //getter
    public String getWebAdress() {
        return webAdress;
    }

    //setter
    public void setWebAdress(String webAdress) {
        this.webAdress = webAdress;
    }
	
	// concrete subclass OnlineRetailer re-defines the method of its concrete superclass AdvertOwner
    @Override
    public void advertise() {
        super.advertise();
        System.out.println("WEB SITE: " + getWebAdress());
    }
}