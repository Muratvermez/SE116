import java.util.ArrayList;
import java.util.Scanner;
import java.security.SecureRandom;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.IOException;
import java.io.EOFException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.NoSuchElementException;

// class Test demonstrates an online shopping system simulation using File I/O
public class Test {
    private static ObjectOutputStream output1;
    private static ObjectOutputStream output2;
    private static ObjectOutputStream output3;
    private static ObjectInputStream input1;
    private static ObjectInputStream input2;
    private static ArrayList<Advert> adverts = new ArrayList<Advert>();
    private static SecureRandom randomPrice = new SecureRandom();
    private static Scanner scan= new Scanner(System.in);

    public static void main(String[] args) {
        openFilesToWrite();
        writeSerializedObjectsIntoFiles();
        closeFilesWritten();

        openFilesToRead();
        readSerializedObjectsFromFiles();
        closeFilesRead();

        System.out.println("Data has read from files...\nThe list is the following: ");
        // to check that the data read from file seems valid
        for(int i = 0; i<adverts.size();i++) {
            adverts.get(i).advertise();
        }

        String temp;
        int tempF;
        int tempNo;
        int choice = 0;

        ArrayList<String> screenResolution = new ArrayList<String>(); // array list to keep the screen resolution values of computers
        ArrayList<Integer> ramSize = new ArrayList<Integer>();// array list to keep the ram sizes of computers

        while(true) { // iterate in while loop until user wants to exit
            menu();
            boolean loopCondition = true;
            do {
                try { // exception handling mechanism to handle with undesired input attempts
                    choice = Integer.parseInt(scan.nextLine());
                    loopCondition = false;
                } catch (Exception e) {
                    System.err.println("Exception..."+ e.getMessage()); // advertise the reason of exception
                    System.err.println("Enter a number... Press 1 or 2 or 3 ...");
                }
            } while(loopCondition);

            switch(choice){
                case 1: // ask user to enter ram size and screen resolution  value of a computer
                    System.out.println("Please enter the screen resolution properties using the following format: x*y (such as 1920*1080).\nYou can enter different properties each in a new line. Enter -1 to stop adding new properties:");
                    temp = scan.nextLine();
                    while(!temp.equals("-1")) { // take value until user enters -1
                        screenResolution.add(temp);
                        temp = scan.nextLine();
                    }

                    System.out.println("Please enter the ram size you wish. You can enter additional ram sizes each separated by a space character. Enter -1 to stop adding new ram sizes:");
                    tempF = scan.nextInt();
                    while(tempF!=-1) {// take value until user enters -1
                        ramSize.add(tempF);
                        tempF = scan.nextInt();
                    }
                    scan.nextLine();

                    System.out.println("Searching..........");
                    for(int i=0; i<adverts.size(); i++) { // search the previously entered input for given parameters
                        //SCREEN RESOLUTION
                        for(int j=0; j<screenResolution.size(); j++) {
                            //RAM SIZE
                            for(int k=0; k<ramSize.size(); k++) {
                                if(adverts.get(i).getComputer().getScreenResolution().equals(screenResolution.get(j)) && adverts.get(i).getComputer().getRamSize()== ramSize.get(k) ){
                                    adverts.get(i).advertise();
                                }
                            }
                        }
                    }

                    System.out.println("Please enter the corresponding ADVERT NO to filter the computer you want to buy: ");
                    tempNo = Integer.parseInt(scan.nextLine());

                    for(int i=0; i<adverts.size(); i++) { // get the advert with given advert number
                        if(adverts.get(i).getADVERT_NO() == tempNo) {
                            adverts.get(i).advertise();
                        }
                    }

                    System.out.println("Press any key to return to Menu....");
                    scan.nextLine();
                    break;
                case 2:
                    System.out.println("Please enter the full name of the advert owner: ");
                    temp=scan.nextLine();
                    boolean check=false;
                    for(int i=0; i<adverts.size(); i++) { // search the previously entered input for given online retail store parameter
                        if(adverts.get(i).getAdvertOwner().getFullName().equals(temp)) {
                            adverts.get(i).advertise();
                            check=true;
                        }
                    }
                    if(!check) {
                        System.out.println("Found nothing....");
                        break;
                    }

                    System.out.println("Please enter the corresponding ADVERT NO to filter the computer you want to buy: ");
                    tempNo = Integer.parseInt(scan.nextLine());

                    for(int i=0; i< adverts.size(); i++) { // get the advert with given advert number
                        if(adverts.get(i).getADVERT_NO() == tempNo) {
                            adverts.get(i).advertise();
                        }
                    }

                    System.out.println("Press any key to return to Menu....");
                    scan.nextLine();
                    break;
                case 3:
                    System.out.println("Exiting...");
                    System.exit(0);
                default:
                    System.out.println("Wrong Entry...."); // warn the user if he/she enters a value which is not an option in menu
            }
        }
    }

    public static void openFilesToWrite(){
        try
        {
            output1 = new ObjectOutputStream(Files.newOutputStream(Paths.get("computers.ser")));
        }
        catch (IOException ioException)
        {
            System.err.println("Error opening first file to write. Terminating...");
            System.exit(1); // terminate the program with a failure status of 1
        }

        try
        {
            output2 = new ObjectOutputStream(Files.newOutputStream(Paths.get("onlineRetailers.ser")));
        }
        catch (IOException ioExcaption)
        {
            System.err.println("Error opening second file to write. Terminating...");
            System.exit(1); // terminate the program with a failure status of 1
        }

        try
        {
            output3 = new ObjectOutputStream(Files.newOutputStream(Paths.get("computerOwners.ser")));
        }
        catch (IOException ioExcaption)
        {
            System.err.println("Error opening third file to write. Terminating...");
            System.exit(1); // terminate the program with a failure status of 1
        }
    }

    public static void writeSerializedObjectsIntoFiles() {
        // create 5 instances from each class Computer, OnlineRetailer, ComputerOwner. After serializing these objects write their data into different files.
        int numberOfIterations = 5;

        System.out.println("To create 5 instances from class Computer, enter the following data values each separated by a space please:");
        for (int i = 1; i <= numberOfIterations; i++) {
            System.out.println("\"value of screen resolution as x*y\" \"ram size\" \"hard drive size\", and \"operating system\" ");
            try {
                output1.writeObject(new Computer(scan.next(), scan.nextInt(), scan.nextInt(), scan.nextLine()));
            }
            catch (NoSuchElementException elementObjection) {
                System.err.println("Invalid Input. Please try again.");
                scan.nextLine(); // discard input and the user will try again
                i--; // do not count an iteration for the invalid input.
            }
            catch (IOException ioException) {
                System.out.println("Error writing to file 'computers.ser'. Terminating.");
                break;
            }
        }

        System.out.println("To create 5 instances from class OnlineRetailer, enter the following data values each separated by a space please:");
        for (int i = 1; i <= numberOfIterations; i++) {
            System.out.println("\"name\" \"id\" \"contact number\", and \"web address\" ");
            try {
                output2.writeObject(new OnlineRetailer(scan.next(),scan.nextInt(),scan.next(),scan.nextLine()));
            }
            catch (NoSuchElementException elementObjection) {
                System.err.println("Invalid Input. Please try again.");
                scan.nextLine(); // discard input and the user will try again
                i--; // do not count an iteration for the invalid input.
            }
            catch (IOException ioException) {
                System.out.println("Error writing to file 'onlineRetailers.ser'. Terminating.");
                break;
            }
        }

        System.out.println("To create 5 instances from class ComputerOwner, enter the following data values each separated by a space please:");
        for (int i = 1; i <= numberOfIterations; i++) {
            System.out.println("\"name\" \"id\" \"contact number\", and \"occupation\" ");
            try {
                output3.writeObject(new ComputerOwner(scan.next(),scan.nextInt(),scan.next(),scan.nextLine()));
            }
            catch (NoSuchElementException elementObjection) {
                System.err.println("Invalid Input. Please try again.");
                scan.nextLine(); // discard input and the user will try again
                i--; // do not count an iteration for the invalid input.
            }
            catch (IOException ioException) {
                System.out.println("Error writing to file 'computerOwners.ser'. Terminating.");
                break;
            }
        }
    }

    public static void closeFilesWritten(){
        try
        {
            if(output1 != null)
                output1.close();
        }
        catch (IOException ioException)
        {
            System.err.println("Error closing file 'computers.ser'. Terminating.");
            System.exit(1); // terminate the program with a failure status of 1
        }
        try
        {
            if(output2 != null)
                output2.close();
        }
        catch (IOException ioException)
        {
            System.err.println("Error closing file 'onlineRetailers.ser'. Terminating.");
            System.exit(1); // terminate the program with a failure status of 1
        }
        try
        {
            if(output3 != null)
                output3.close();
        }
        catch (IOException ioException)
        {
            System.err.println("Error closing file 'computerOwners.ser'. Terminating.");
            System.exit(1); // terminate the program with a failure status of 1
        }

    }

    public static void openFilesToRead() {
        try {
            input1 = new ObjectInputStream(Files.newInputStream(Paths.get("computers.ser")));
        } catch (IOException ioException) {
            System.err.println("Error opening the file 'computers.ser'.");
            System.exit(1); // terminate the program with a failure status of 1

        }

        try {
            input2 = new ObjectInputStream(Files.newInputStream(Paths.get("computerOwners.ser")));
        } catch (IOException ioException) {
            System.err.println("Error opening the file 'computerOwners.ser'.");
            System.exit(1); // terminate the program with a failure status of 1

        }
    }

    public static void readSerializedObjectsFromFiles() {
        int number = 1;
        try {
            while (true) {
                Computer computer = (Computer) input1.readObject();
                AdvertOwner advertOwner = (ComputerOwner) input2.readObject();
                adverts.add(new Advert(number, advertOwner, computer, randomPrice.nextInt(500000)));
                number++;
            }
        }
        catch (EOFException endOfFileException) {
            System.out.println("No more records.");
        }
        catch (ClassNotFoundException classNotFoundException) {
            System.err.println("Invalid object type. Terminating.");
        }
        catch (IOException ioException) {
            System.err.println("Error reading from file. Terminating.");
        }
    }

    public static void closeFilesRead(){
        try
        {
            if(input1 != null)
                input1.close();
        }
        catch (IOException ioException)
        {
            System.err.println("Error closing file 'computers.ser'. Terminating.");
            System.exit(1); // terminate the program with a failure status of 1
        }
        try
        {
            if(input2 != null)
                input2.close();
        }
        catch (IOException ioException)
        {
            System.err.println("Error closing file 'computerOwners.ser'. Terminating.");
            System.exit(1); // terminate the program with a failure status of 1
        }
    }

    public static void menu(){ // method to show the options
        System.out.println("<<<<<<<ONLINE SHOPPING SEARCH PROGRAM>>>>>>>" );
        System.out.println("PRESS 1 to search for a computer by the properties you seek" );
        System.out.println("PRESS 2 to search for a computer by checking an advert owner" );
        System.out.println("PRESS 3 to quit" );
        System.out.println("\nPlease enter your choice to continue..." );
    }
}
