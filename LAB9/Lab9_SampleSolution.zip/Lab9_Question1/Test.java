/*  Abstract classes cannot be used to instantiate objects; because abstract classes are incomplete.
    Concrete classes can be used to instantiate objects; because concrete classes are complete.
    Abstract base classes can be used to declare references to refer to concrete derived class objects.
*/

// concrete class Test
import java.util.ArrayList;
import java.util.Scanner;

public class Test {
    public static void displayMenu() {
        System.out.println("MENU OPTIONS [1 through 3]:");
        System.out.println("*** Press 1 to add products to your cart     ***");
        System.out.println("*** Press 2 to checkout                      ***");
        System.out.println("*** Press 3 to terminate the program         ***");
        System.out.print("Enter your choice: ");
    }
    public static void main(String[] args) {
        Scanner scan=new Scanner(System.in);
        ArrayList<Product> shoppingCenter = new ArrayList<Product>();
        int tempID, tempPageNumber;
        String tempName, tempGenre;
        double tempPrice, tempWidth, tempLength, tempCalorie;

        // Furniture objects
        final int NUMBER_OF_ITERATIONS = 5;  // number of the objects to be created from each subclass
        for(int i=0; i<NUMBER_OF_ITERATIONS; i++){
            System.out.print("Please enter furniture ID: ");
            tempID = Integer.parseInt(scan.nextLine());
            System.out.print("Please enter furniture name: ");
            tempName = scan.nextLine();
            System.out.print("Please enter furniture base price: ");
            tempPrice = Double.parseDouble(scan.nextLine());
            System.out.print("Please enter furniture width: ");
            tempWidth = Double.parseDouble(scan.nextLine());
            System.out.print("Please enter furniture length: ");
            tempLength = Double.parseDouble(scan.nextLine());
            Furniture furnitureReference = new Furniture(tempID, tempName, tempPrice, tempWidth, tempLength);	// creating a new Furniture object
            shoppingCenter.add(furnitureReference); 	// adding the reference of the object into the ArrayList
            System.out.println();
        }

        // Book objects
        for(int i=0;i<NUMBER_OF_ITERATIONS;i++){
            System.out.print("Please enter book ID: ");
            tempID = Integer.parseInt(scan.nextLine());
            System.out.print("Please enter book name: ");
            tempName=scan.nextLine();
            System.out.print("Please enter book base price: ");
            tempPrice = Double.parseDouble(scan.nextLine());
            System.out.print("Please enter book genre: ");
            tempGenre = scan.nextLine();
            System.out.print("Please enter book page number: ");
            tempPageNumber = Integer.parseInt(scan.nextLine());
            Book bookReference = new Book(tempID, tempName, tempPrice, tempGenre, tempPageNumber);	// creating a new Book object
            shoppingCenter.add(bookReference); 	// adding the reference of the object into the ArrayList
            System.out.println();
        }
		
		// PetFood objects
        for(int i=0; i<NUMBER_OF_ITERATIONS; i++){
            System.out.print("Please enter pet food ID: ");
            tempID = Integer.parseInt(scan.nextLine());
            System.out.print("Please enter pet food name: ");
            tempName = scan.nextLine();
            System.out.print("Please enter pet food base price: ");
            tempPrice = Double.parseDouble(scan.nextLine());
            System.out.print("Please enter pet food calorie: ");
            tempCalorie = Double.parseDouble(scan.nextLine());
            PetFood petFoodReference = new PetFood(tempID, tempName, tempPrice, tempCalorie);	// creating a new PetFood object
            shoppingCenter.add(petFoodReference); 	// adding the reference of the object into the ArrayList
            System.out.println();
        }


        System.out.println();
        System.out.println("Welcome to IUE-Mart :)");
        System.out.println();

        ArrayList<Product> shoppingCart = new ArrayList<Product>();

        int userChoice;
        double totalActualPrice;
        boolean isProductAvailable;
        while(true) {
            displayMenu();
            userChoice = Integer.parseInt(scan.nextLine());
            switch (userChoice) {
                case 1:
                    System.out.print("Please enter the name of the product you want to buy: ");
                    tempName = scan.nextLine();

                    isProductAvailable = false;
                    for (Product item : shoppingCenter) {
                        if (item.getName().equals(tempName)) {
                            shoppingCart.add(item);
                            System.out.println("The corresponding product is added into your shopping cart.");
                            isProductAvailable = true;
                            break;
                        }
                    }
                    if (!isProductAvailable) {
                        System.out.println("Such a product is not available in the shopping center IUE-Mart.");
                    }

                    break;
                case 2:
                    System.out.println("Checking out...");
                    System.out.println("Here is the bill: ");

                    totalActualPrice = 0.0;
                    for (Product element : shoppingCart) {
                        element.display(); // run-time polymorphism (run-time binding)
                        totalActualPrice += element.calculateActualPrice();    // using run-time polymorphism, compute the sum of the actual prices of all products bought
                    }
                    System.out.println("------------------------------");
                    System.out.printf("%30s", "TOTAL");
                    System.out.printf("%15.3f \n", totalActualPrice);
                    System.out.println("Thanks for using IUE-Mart...");
                    System.exit(0); // the program quits
                case 3:
                    System.out.println("Thanks for using IUE-Mart...");
                    System.exit(0); // the program quits
            }
        }
    }
} // end of class Test