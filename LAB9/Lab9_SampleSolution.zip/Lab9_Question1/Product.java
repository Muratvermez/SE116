/* Product Inheritance Hierarchy consists of the following classes:
   The abstract superclass Product, and three concrete subclasses (i.e., Furniture, PetFood, and Book)
*/

/* Abstract classes cannot be used to instantiate objects; because abstract classes are incomplete.
   Concrete classes can be used to instantiate objects; because concrete classes are complete.
   A subclass of an abstract superclass should complete the missing parts in order to become a concrete class, otherwise the subclass would be abstract too.
*/

// abstract superclass Product
public abstract class Product {
    private final int ID;  // common data members
    private final String NAME;
    private double basePrice;
    private double taxRate;

    /* set methods are not necessary for final data members
    public void setId(int productId) {
        if(productID < 0)  // argument validation (input validation)
            productID = 0;
        ID = productID;
    }*/
    public int getId() {
        return ID;
    }

    /* set methods are not necessary for final data members
    /*
    public void setName(String productName) {
        NAME = productName;
    }
    */
    public String getName() {
        return NAME;
    }

    public void setBasePrice(double productBasePrice) {
        if(productBasePrice < 0.0)
            productBasePrice = 0.0;
        basePrice = productBasePrice;
    }
    public double getBasePrice() {
        return basePrice;
    }

    public void setTaxRate(double productTaxRate) {
        if(productTaxRate < 0.0 || productTaxRate > 1.0)
            productTaxRate = 0.0;
        taxRate = productTaxRate;
    }
    public double getTaxRate() {
        return taxRate;
    }

    public Product(int productId, String productName, double productBasePrice, double productTaxRate) { // parameterized constructor
        if(productId < 0)  // argument validation (input validation)
            productId = 0;
        ID = productId;
        NAME = productName;
        setBasePrice(productBasePrice);
        setTaxRate(productTaxRate);
    }

    public void display() {
        System.out.printf("%10d", getId());
        System.out.printf("%30s", getName());
        System.out.printf("%15.3f", getBasePrice());
        System.out.printf("%5.2f", getTaxRate());
    }

    // The following method is declared but is not defined; hence the method implementation is incomplete. Therefore, the method is abstract.
    public abstract double calculateActualPrice(); // abstract method

}