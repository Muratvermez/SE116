// concrete subclass Furniture
public class Furniture extends Product {
    private double width; // extra data member
    private double length; // extra data member

    public void setWidth(double width) {
        if(width < 0.1) // argument validation (input validation)
        	width = 0.1;
        this.width = width;
    }
    public double getWidth() {
        return width;
    }

    public double getLength() {
		return length;
	}
	public void setLength(double length) {
		this.length = length;
	}
	
	
	public Furniture(int furnitureId, String furnitureName, double furnitureBasePrice, double furnitureTaxRate, double furnitureWidth, double furnitureLength) { // parameterized constructor
        super(furnitureId, furnitureName, furnitureBasePrice, furnitureTaxRate);
        setWidth(furnitureWidth);
        setLength(furnitureLength);
    }
    public Furniture(int furnitureId, String furnitureName, double furnitureBasePrice, double furnitureWidth, double furnitureLength) { // constructor is overloaded
        super(furnitureId, furnitureName, furnitureBasePrice, 0.18);
        setWidth(furnitureWidth);
        setLength(furnitureLength);
    }

    @Override
    public double calculateActualPrice() { // The method is not abstract in this subclass. Therefore, the method is implemented (i.e., the method is complete) here.
        return getBasePrice()*getWidth()*getLength()*(1+getTaxRate());
    }

    @Override
    public void display() {
        super.display();
        System.out.printf("%15.3f", getWidth());
        System.out.printf("%15.3f", getLength());
        System.out.printf("%15.3f\n", calculateActualPrice());
    }

} // end of class Furniture