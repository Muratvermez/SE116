// concrete subclass Book
public class Book extends Product {
    private String genre; // extra data member
	private int pageNumber; // extra data member

    public String getGenre() {
		return genre;
	}
	public void setGenre(String bookGenre) {
		genre = bookGenre;
	}
	public void setPageNumber(int bookPageNumber) {
        if(bookPageNumber < 10) // argument validation (input validation)
        	bookPageNumber = 10;
        pageNumber = bookPageNumber;
    }
    public int getPageNumber() {
        return pageNumber;
    }

    public Book(int bookId, String bookName, double bookBasePrice, double bookTaxRate, String bookGenre, int bookPageNumber) { // parameterized constructor
        super(bookId, bookName, bookBasePrice, bookTaxRate);
        setGenre(bookGenre);
        setPageNumber(bookPageNumber);
    }
    public Book(int bookId, String bookName, double bookBasePrice, String bookGenre, int bookPageNumber) { // constructor is overloaded
        super(bookId, bookName, bookBasePrice, 0.00);
        setGenre(bookGenre);
        setPageNumber(bookPageNumber);
    }

    @Override
    public double calculateActualPrice() { // The method is not abstract in this subclass. Therefore, the method is implemented (i.e., the method is complete) here.
        return getBasePrice()*(getPageNumber()*0.2)*(1+getTaxRate());
    }

    @Override
    public void display() {
        super.display();
        System.out.printf("%15s", getGenre());
        System.out.printf("%15d", getPageNumber());
        System.out.printf("%15.3f\n", calculateActualPrice());
    }

} // end of class Book
