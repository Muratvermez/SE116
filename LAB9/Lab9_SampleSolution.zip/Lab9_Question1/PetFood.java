// concrete subclass PetFood
public class PetFood extends Product {
    private double calorie; // extra data member

    public void setCalorie(double foodCalorie) {
        if(foodCalorie < 0.0) // argument validation (input validation)
            foodCalorie = 0.0;
        calorie = foodCalorie;
    }
    public double getCalorie() {
        return calorie;
    }

    public PetFood(int foodId, String foodName, double foodBasePrice, double foodTaxRate, double foodCalorie) { // parameterized constructor
        super(foodId, foodName, foodBasePrice, foodTaxRate);
        setCalorie(foodCalorie);
    }
    public PetFood(int foodId, String foodName, double foodBasePrice, double foodCalorie) { // constructor is overloaded
        super(foodId, foodName, foodBasePrice, 0.08);
        setCalorie(foodCalorie);
    }

    @Override
    public double calculateActualPrice() { // The method is not abstract in this subclass. Therefore, the method is implemented (i.e., the method is complete) here.
        return getBasePrice()*getCalorie()*(1+getTaxRate());
    }

    @Override
    public void display() {
        super.display();
        System.out.printf("%15.3f", getCalorie());
        System.out.printf("%15.3f\n", calculateActualPrice());
    }

} // end of class PetFood